package fr.jmproduction.pocketdoor;

import fr.jmproduction.pocketdoor.block.ResonanceChamberBlock;


import fr.jmproduction.pocketdoor.block.CartostellaireBlock;
import fr.jmproduction.pocketdoor.block.entity.ResonanceChamberBlockEntity;
import fr.jmproduction.pocketdoor.entity.PapierFoudreProjectile;
import fr.jmproduction.pocketdoor.item.PapierFoudreItem;
import fr.jmproduction.pocketdoor.menu.ResonanceChamberMenu;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1747;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1814;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_3614;
import net.minecraft.class_3917;
import net.minecraft.class_4048;
import net.minecraft.class_4970;

public final class Content {
    public static final class_2248 TERTARIUM_ORE = registerBlock(
            "tertarium_ore",
            new class_2248(class_4970.class_2251.method_9637(class_3614.field_15914)
                    .method_29292()
                    .method_9632(3.0F)));

    public static final class_2248 DEEPSLATE_TERTARIUM_ORE = registerBlock(
            "deepslate_tertarium_ore",
            new class_2248(class_4970.class_2251.method_9637(class_3614.field_15914)
                    .method_29292()
                    .method_9632(4.5F)));

    public static final class_1792 TERTARIUM_ORE_ITEM = registerItem(
            "tertarium_ore",
            new class_1747(TERTARIUM_ORE,
                    new class_1792.class_1793().method_7892(class_1761.field_7931)));

    public static final class_1792 RAW_TERTARIUM = registerItem(
            "raw_tertarium",
            new class_1792(new class_1792.class_1793().method_7892(class_1761.field_7929)));

    public static final class_1792 DEEPSLATE_TERTARIUM_ORE_ITEM = registerItem(
            "deepslate_tertarium_ore",
            new class_1747(DEEPSLATE_TERTARIUM_ORE,
                    new class_1792.class_1793().method_7892(class_1761.field_7931)));

    public static final class_1792 PURIFIED_TERTARIUM_CRYSTAL = registerItem(
            "purified_tertarium_crystal",
            new class_1792(new class_1792.class_1793().method_7892(class_1761.field_7929)));

    public static final class_2248 CARTOSTELLAIRE = registerBlock(
            "cartostellaire",
            new CartostellaireBlock(class_4970.class_2251.method_9637(class_3614.field_15914)
                    .method_29292()
                    .method_9632(5.0F)));

    public static final class_1792 CARTOSTELLAIRE_ITEM = registerItem(
            "cartostellaire",
            new class_1747(CARTOSTELLAIRE,
                    new class_1792.class_1793()
                            .method_7892(class_1761.field_7928)
                            .method_7894(class_1814.field_8904)));

    public static final class_2248 RESONANCE_CHAMBER = registerBlock(
            "resonance_chamber",
            new ResonanceChamberBlock(class_4970.class_2251.method_9637(class_3614.field_15914)
                    .method_29292()
                    .method_9632(5.0F)
                    .method_9631(ResonanceChamberBlock::light)));

    public static final class_1792 RESONANCE_CHAMBER_ITEM = registerItem(
            "resonance_chamber",
            new class_1747(RESONANCE_CHAMBER,
                    new class_1792.class_1793().method_7892(class_1761.field_7928)));

    public static final class_2591<ResonanceChamberBlockEntity> RESONANCE_CHAMBER_ENTITY =
            class_2378.method_10230(
                    class_2378.field_11137,
                    id("resonance_chamber"),
                    FabricBlockEntityTypeBuilder.create(
                            ResonanceChamberBlockEntity::new,
                            RESONANCE_CHAMBER).build(null));

    public static final class_3917<ResonanceChamberMenu> RESONANCE_CHAMBER_MENU =
            class_2378.method_10230(
                    class_2378.field_17429,
                    id("resonance_chamber"),
                    new class_3917<>(ResonanceChamberMenu::new));

    public static final class_1792 PAPIER_FOUDRE = registerItem(
            "papier_foudre",
            new PapierFoudreItem(new class_1792.class_1793()
                    .method_7889(16)
                    .method_7894(class_1814.field_8903)
                    .method_7892(class_1761.field_7932)));

    public static final class_1299<PapierFoudreProjectile> PAPIER_FOUDRE_PROJECTILE =
            class_2378.method_10230(
                    class_2378.field_11145,
                    id("papier_foudre_projectile"),
                    FabricEntityTypeBuilder.<PapierFoudreProjectile>create(
                            class_1311.field_17715,
                            (type, level) -> new PapierFoudreProjectile(type, level))
                            .dimensions(class_4048.method_18385(0.25F, 0.25F))
                            .trackRangeBlocks(4)
                            .trackedUpdateRate(10)
                            .build());

    private static class_2248 registerBlock(String name, class_2248 block) {
        return class_2378.method_10230(class_2378.field_11146, id(name), block);
    }

    private static class_1792 registerItem(String name, class_1792 item) {
        return class_2378.method_10230(class_2378.field_11142, id(name), item);
    }

    public static class_2960 id(String name) {
        return new class_2960(PocketDoorMod.MOD_ID, name);
    }

    private Content() {
    }
}
