package fr.jmproduction.pocketdoor;

import com.mojang.brigadier.CommandDispatcher;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1747;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1937;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2668;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3614;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import fr.jmproduction.pocketdoor.block.PocketDoorBlock;
import fr.jmproduction.pocketdoor.network.ModMessages;
import fr.jmproduction.pocketdoor.worldgen.TertariumWorldGen;

public class PocketDoorMod implements ModInitializer {
    public static final String MOD_ID = "pocketdoor";
    public static final class_2960 POCKET_DOOR_ID = new class_2960(MOD_ID, "pocket_door");
    public static final class_5321<class_1937> OSSUAIRE = class_5321.method_29179(class_2378.field_25298, new class_2960(MOD_ID, "ossuaire_flottant"));
    public static final class_2248 POCKET_DOOR = class_2378.method_10230(class_2378.field_11146, POCKET_DOOR_ID, new PocketDoorBlock(class_4970.class_2251.method_9637(class_3614.field_15932).method_9632(2)));
    public static final class_1792 POCKET_DOOR_ITEM = class_2378.method_10230(class_2378.field_11142, POCKET_DOOR_ID, new class_1747(POCKET_DOOR, new class_1792.class_1793().method_7892(class_1761.field_7928)));
    public static final class_3414 AMBIANCE_SILGO = sound("ambiance_silgo");
    public static final class_3414 REPLIQUE_1_SILGO = sound("replique_1_silgo");
    public static final class_3414 REPLIQUE_2_SILGO = sound("replique_2_silgo");
    public static final class_3414 REPLIQUE_3_SILGO = sound("replique_3_silgo");
    public static final class_3414 REPLIQUE_4_SILGO = sound("replique_4_silgo");
    public static final class_3414 REPLIQUE_5_SILGO = sound("replique_5_silgo");
    public static final class_3414 REPLIQUE_6_SILGO = sound("replique_6_silgo");
    private static class_3414 sound(String name) { class_2960 id = new class_2960(MOD_ID, name); return class_2378.method_10230(class_2378.field_11156, id, new class_3414(id)); }
    @Override public void onInitialize() {
        Content.class.getName(); ModMessages.registerC2SPackets(); TertariumWorldGen.register();
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> registerCommands(dispatcher));
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            class_3218 ossuaire = server.method_3847(OSSUAIRE);
            if (ossuaire == null || ossuaire.method_18456().isEmpty()) return;

            // En 1.19.2, le client ne prend pas l'etat meteo d'un ServerLevel
            // non-Overworld pour le rendu pluie/neige. L'Overworld porte donc
            // l'etat de pluie, puis les evenements sont emis directement aux
            // joueurs qui se trouvent dans la dimension custom.
            class_3218 overworld = server.method_30002();
            overworld.method_27910(0, 6000, true, false);

            // Re-emettre periodiquement les deux etats evite qu'un joueur qui
            // vient d'entrer, ou qui a rate un paquet, reste sans precipitation.
            if (server.method_3780() % 20 == 0) {
                class_2668 started = new class_2668(
                        class_2668.field_25646, 0.0F);
                class_2668 rainLevel = new class_2668(
                        class_2668.field_25652, 1.0F);
                for (class_3222 player : ossuaire.method_18456()) {
                    player.field_13987.method_14364(started);
                    player.field_13987.method_14364(rainLevel);
                }
            }
        });
    }
    private static void registerCommands(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(class_2170.method_9247("pocketdoor").then(class_2170.method_9247("tp").then(class_2170.method_9247("ossuaire").executes(ctx -> {
            class_3222 player = ctx.getSource().method_9207();
            class_3218 target = player.method_5682().method_3847(OSSUAIRE);
            if (target == null) return 0;
            player.method_14251(target, 0.5, 80.0, 0.5, player.method_36454(), player.method_36455());
            return 1;
        }))));
    }
}
