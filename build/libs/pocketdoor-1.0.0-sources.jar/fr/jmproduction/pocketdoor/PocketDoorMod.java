package fr.jmproduction.pocketdoor;
import fr.jmproduction.pocketdoor.block.PocketDoorBlock; import fr.jmproduction.pocketdoor.network.ModMessages; import net.fabricmc.api.ModInitializer;
import net.minecraft.class_1747;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_3614;
import net.minecraft.class_4970;
import net.minecraft.world.item.*; import net.minecraft.world.level.block.*;
public class PocketDoorMod implements ModInitializer { public static final String MOD_ID="pocketdoor"; public static final class_2960 POCKET_DOOR_ID=new class_2960(MOD_ID,"pocket_door"); public static final class_2248 POCKET_DOOR=class_2378.method_10230(class_2378.field_11146,POCKET_DOOR_ID,new PocketDoorBlock(class_4970.class_2251.method_9637(class_3614.field_15932).method_9632(2))); public static final class_1792 POCKET_DOOR_ITEM=class_2378.method_10230(class_2378.field_11142,POCKET_DOOR_ID,new class_1747(POCKET_DOOR,new class_1792.class_1793().method_7892(class_1761.field_7928))); public static final class_3414 AMBIANCE_SILGO=sound("ambiance_silgo"), REPLIQUE_1_SILGO=sound("replique_1_silgo"), REPLIQUE_2_SILGO=sound("replique_2_silgo"), REPLIQUE_3_SILGO=sound("replique_3_silgo"), REPLIQUE_4_SILGO=sound("replique_4_silgo"), REPLIQUE_5_SILGO=sound("replique_5_silgo"), REPLIQUE_6_SILGO=sound("replique_6_silgo"); private static class_3414 sound(String n){class_2960 id=new class_2960(MOD_ID,n);return class_2378.method_10230(class_2378.field_11156,id,new class_3414(id));} @Override public void onInitialize(){ModMessages.registerC2SPackets();}}
