package fr.jmproduction.pocketdoor.block;
import fr.jmproduction.pocketdoor.Content; import fr.jmproduction.pocketdoor.network.ModMessages;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2746;
import net.minecraft.class_3965;
public final class CartostellaireBlock extends class_2248 { public static final class_2746 ACTIVATED=class_2746.method_11825("activated"); public CartostellaireBlock(class_2251 p){super(p);method_9590(field_10647.method_11664().method_11657(ACTIVATED,false));} @Override protected void method_9515(class_2689.class_2690<class_2248,class_2680>b){b.method_11667(ACTIVATED);}@Override public class_1269 method_9534(class_2680 s,class_1937 l,class_2338 p,class_1657 pl,class_1268 h,class_3965 hit){class_1799 st=pl.method_5998(h);if(st.method_31574(Content.PURIFIED_TERTARIUM_CRYSTAL)&&!s.method_11654(ACTIVATED)){if(!l.field_9236){l.method_8652(p,s.method_11657(ACTIVATED,true),3);if(!pl.method_31549().field_7477)st.method_7934(1);pl.method_7353(class_2561.method_43470("Le Cartostellaire peut maintenant s'activer"),true);}return class_1269.method_29236(l.field_9236);}if(!s.method_11654(ACTIVATED)){if(!l.field_9236)pl.method_7353(class_2561.method_43470("Le Cartostellaire n'as pas assez d'énergie pour s'activer"),true);return class_1269.method_29236(l.field_9236);}if(st.method_7960()){if(!l.field_9236)ModMessages.sendCartostellaireStart((net.minecraft.class_3222)pl,p);return class_1269.method_29236(l.field_9236);}return class_1269.field_5811;}}
