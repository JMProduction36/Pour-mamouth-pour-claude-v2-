package fr.jmproduction.pocketdoor.block;

import fr.jmproduction.pocketdoor.network.ModMessages;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1657;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2561;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3222;
import net.minecraft.class_3726;
import net.minecraft.class_3965;

public class PocketDoorBlock extends class_2383 {
    private static final class_265 NORTH_SHAPE = class_259.method_1081(0, 0, 0, 1, 1, 0.625);
    private static final class_265 SOUTH_SHAPE = class_259.method_1081(0, 0, 0.375, 1, 1, 1);
    private static final class_265 EAST_SHAPE = class_259.method_1081(0.375, 0, 0, 1, 1, 1);
    private static final class_265 WEST_SHAPE = class_259.method_1081(0, 0, 0, 0.625, 1, 1);

    public PocketDoorBlock(class_2251 properties) {
        super(properties);
        method_9590(field_10647.method_11664().method_11657(field_11177, class_2350.field_11043));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) { builder.method_11667(field_11177); }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        return switch (state.method_11654(field_11177)) {
            case field_11035 -> SOUTH_SHAPE; case field_11034 -> EAST_SHAPE; case field_11039 -> WEST_SHAPE; default -> NORTH_SHAPE;
        };
    }

    @Override
    public class_1269 method_9534(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        if (!level.field_9236 && player instanceof class_3222 serverPlayer) {
            if (!ModMessages.isFinished(serverPlayer)) {
                serverPlayer.method_6092(new class_1293(class_1294.field_38092, Integer.MAX_VALUE, 0, false, false));
                ModMessages.scheduleDialogueBlindness(serverPlayer, 7);
                ModMessages.sendStartDialogue(serverPlayer);
            } else {
                player.method_7353(class_2561.method_43470("Cette porte ne semble pas réagir à votre présence pour l'instant."), true);
            }
        }
        return class_1269.method_29236(level.field_9236);
    }
}
