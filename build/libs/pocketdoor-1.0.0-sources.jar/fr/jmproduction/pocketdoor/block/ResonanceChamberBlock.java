package fr.jmproduction.pocketdoor.block;

import fr.jmproduction.pocketdoor.Content;
import fr.jmproduction.pocketdoor.block.entity.ResonanceChamberBlockEntity;
import net.minecraft.class_1264;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2754;
import net.minecraft.class_3542;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import net.minecraft.class_5819;

public class ResonanceChamberBlock extends class_2237 {
    public enum Stage implements class_3542 {
        INACTIVE,
        ACTIVATING,
        RESONATING,
        COMPLETE;

        @Override
        public String method_15434() {
            return name().toLowerCase();
        }
    }

    public static final class_2754<Stage> STAGE = class_2754.method_11850("stage", Stage.class);

    public ResonanceChamberBlock(class_2251 properties) {
        super(properties);
        method_9590(field_10647.method_11664().method_11657(STAGE, Stage.INACTIVE));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(STAGE);
    }

    @Override
    public class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new ResonanceChamberBlockEntity(pos, state);
    }

    @Override
    public <T extends class_2586> class_5558<T> method_31645(
            class_1937 level,
            class_2680 state,
            class_2591<T> blockEntityType
    ) {
        return method_31618(
                blockEntityType,
                Content.RESONANCE_CHAMBER_ENTITY,
                ResonanceChamberBlockEntity::tick
        );
    }

    public static int light(class_2680 state) {
        return switch (state.method_11654(STAGE)) {
            case INACTIVE -> 0;
            case ACTIVATING -> 5;
            case RESONATING -> 10;
            case COMPLETE -> 15;
        };
    }

    @Override
    public class_1269 method_9534(
            class_2680 state,
            class_1937 level,
            class_2338 pos,
            class_1657 player,
            class_1268 hand,
            class_3965 hit
    ) {
        if (!level.field_9236 && level.method_8321(pos) instanceof ResonanceChamberBlockEntity blockEntity) {
            player.method_17355(blockEntity);
        }

        return class_1269.method_29236(level.field_9236);
    }

    @Override
    public void method_9536(
            class_2680 state,
            class_1937 level,
            class_2338 pos,
            class_2680 newState,
            boolean movedByPiston
    ) {
        if (state.method_26204() != newState.method_26204()
                && level.method_8321(pos) instanceof ResonanceChamberBlockEntity blockEntity) {
            class_1264.method_5451(level, pos, blockEntity);
        }

        super.method_9536(state, level, pos, newState, movedByPiston);
    }

    @Override
    public void method_9496(class_2680 state, class_1937 level, class_2338 pos, class_5819 random) {
        if (random.method_43048(5) != 0) {
            return;
        }

        Stage stage = state.method_11654(STAGE);
        if (stage == Stage.ACTIVATING || stage == Stage.RESONATING) {
            double angle = random.method_43058() * 6.28;
            double distance = 0.65;
            level.method_8406(
                    stage == Stage.RESONATING ? class_2398.field_11215 : class_2398.field_11207,
                    pos.method_10263() + 0.5 + Math.cos(angle) * distance,
                    pos.method_10264() + 0.7 + random.method_43058() * 0.5,
                    pos.method_10260() + 0.5 + Math.sin(angle) * distance,
                    0,
                    0.01,
                    0
            );
        }
    }
}
