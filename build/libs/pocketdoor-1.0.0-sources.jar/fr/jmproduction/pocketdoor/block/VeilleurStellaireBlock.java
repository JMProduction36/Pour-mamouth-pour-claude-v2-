package fr.jmproduction.pocketdoor.block;

import fr.jmproduction.pocketdoor.network.ModMessages;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3965;

/** Powered anomaly detector. The server stores arming on the player's persistent NBT. */
public final class VeilleurStellaireBlock extends class_2248 {
    public VeilleurStellaireBlock(class_2251 properties) { super(properties); method_9590(field_10647.method_11664().method_11657(class_2741.field_12484, false)); }
    @Override protected void method_9515(class_2689.class_2690<class_2248, class_2680> b) { b.method_11667(class_2741.field_12484); }
    @Override public void method_9615(class_2680 state, class_1937 level, class_2338 pos, class_2680 old, boolean moved) { if (!level.field_9236) updatePower(state, level, pos); super.method_9615(state, level, pos, old, moved); }
    @Override public void method_9612(class_2680 state, class_1937 level, class_2338 pos, class_2248 block, class_2338 from, boolean moved) { if (!level.field_9236) updatePower(state, level, pos); super.method_9612(state, level, pos, block, from, moved); }
    private void updatePower(class_2680 state, class_1937 level, class_2338 pos) { boolean powered=level.method_8479(pos); if (powered != state.method_11654(class_2741.field_12484)) { level.method_8652(pos,state.method_11657(class_2741.field_12484,powered),3); level.method_8396(null,pos,powered?class_3417.field_14700:class_3417.field_14979,class_3419.field_15245,1.0F,1.0F); } }
    @Override public class_1269 method_9534(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        if (!level.field_9236) { boolean powered=state.method_11654(class_2741.field_12484); player.method_43496(class_2561.method_43470(powered ? "Le Veilleur stellaire est alimenté, il peut détecter les fluctuations dans l'univers" : "Le Veilleur stellaire a besoin d'alimentation pour détecter des anomalies")); if (powered) ModMessages.armWatcher((net.minecraft.class_3222) player, pos); }
        return class_1269.method_29236(level.field_9236);
    }
}
