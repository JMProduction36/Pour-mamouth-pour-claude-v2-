package fr.jmproduction.pocketdoor.block.entity;

import fr.jmproduction.pocketdoor.Content;
import fr.jmproduction.pocketdoor.block.ResonanceChamberBlock;
import fr.jmproduction.pocketdoor.menu.ResonanceChamberMenu;
import fr.jmproduction.pocketdoor.recipe.ResonanceRecipes;
import net.minecraft.class_1262;
import net.minecraft.class_1278;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3908;
import net.minecraft.class_3913;
import org.jetbrains.annotations.Nullable;

public class ResonanceChamberBlockEntity extends class_2586 implements class_1278, class_3908 {
    private final class_2371<class_1799> items = class_2371.method_10213(2, class_1799.field_8037);
    private int progress;
    private int maxProgress;
    private int stageTimer;
    private ResonanceChamberBlock.Stage stage = ResonanceChamberBlock.Stage.INACTIVE;

    private final class_3913 data = new class_3913() {
        @Override public int method_17390(int index) {
            return switch (index) {
                case 0 -> progress;
                case 1 -> maxProgress;
                case 2 -> stage.ordinal();
                case 3 -> stageTimer;
                default -> 0;
            };
        }
        @Override public void method_17391(int index, int value) {
            if (index == 0) progress = value;
            else if (index == 1) maxProgress = value;
            else if (index == 2) setStage(ResonanceChamberBlock.Stage.values()[Math.max(0, Math.min(3, value))]);
            else if (index == 3) stageTimer = value;
        }
        @Override public int method_17389() { return 4; }
    };

    public ResonanceChamberBlockEntity(class_2338 pos, class_2680 state) {
        super(Content.RESONANCE_CHAMBER_ENTITY, pos, state);
    }

    public static void tick(class_1937 level, class_2338 pos, class_2680 state, ResonanceChamberBlockEntity blockEntity) {
        if (level.field_9236) return;
        class_1799 input = blockEntity.items.get(0);
        ResonanceRecipes.Entry recipe = ResonanceRecipes.find(input);
        if (recipe == null || !blockEntity.canAcceptOutput(recipe.output())) {
            blockEntity.resetProcess();
            return;
        }
        if (blockEntity.stage == ResonanceChamberBlock.Stage.INACTIVE) {
            blockEntity.maxProgress = recipe.ticks();
            blockEntity.stageTimer = 0;
            blockEntity.setStage(ResonanceChamberBlock.Stage.ACTIVATING);
        }
        if (blockEntity.stage == ResonanceChamberBlock.Stage.ACTIVATING) {
            if (++blockEntity.stageTimer >= 40) {
                blockEntity.stageTimer = 0;
                blockEntity.setStage(ResonanceChamberBlock.Stage.RESONATING);
            }
        } else if (blockEntity.stage == ResonanceChamberBlock.Stage.RESONATING) {
            blockEntity.maxProgress = recipe.ticks();
            if (++blockEntity.progress >= blockEntity.maxProgress) {
                blockEntity.progress = 0;
                blockEntity.stageTimer = 0;
                blockEntity.setStage(ResonanceChamberBlock.Stage.COMPLETE);
            }
        } else if (blockEntity.stage == ResonanceChamberBlock.Stage.COMPLETE
                && ++blockEntity.stageTimer >= 20) {
            blockEntity.stageTimer = 0;
            blockEntity.finish(recipe.output());
            blockEntity.setStage(ResonanceChamberBlock.Stage.INACTIVE);
        }
        blockEntity.method_5431();
    }

    private boolean canAcceptOutput(class_1799 result) {
        class_1799 output = items.get(1);
        return output.method_7960()
                || (class_1799.method_31577(output, result)
                && output.method_7947() + result.method_7947() <= output.method_7914());
    }

    private void finish(class_1799 result) {
        if (items.get(1).method_7960()) items.set(1, result.method_7972());
        else items.get(1).method_7933(result.method_7947());
        items.get(0).method_7934(1);
    }

    private void resetProcess() {
        if (stage != ResonanceChamberBlock.Stage.INACTIVE || progress != 0 || stageTimer != 0) {
            setStage(ResonanceChamberBlock.Stage.INACTIVE);
        }
        progress = 0;
        maxProgress = 0;
        stageTimer = 0;
    }

    private void setStage(ResonanceChamberBlock.Stage newStage) {
        if (stage == newStage) return;
        stage = newStage;
        if (field_11863 != null) {
            field_11863.method_8652(field_11867, method_11010().method_11657(ResonanceChamberBlock.STAGE, newStage), 3);
        }
    }

    public class_3913 data() { return data; }

    @Override public void method_11014(class_2487 tag) {
        super.method_11014(tag);
        class_1262.method_5429(tag, items);
        progress = tag.method_10550("Progress");
        maxProgress = tag.method_10550("MaxProgress");
        stageTimer = tag.method_10550("StageTimer");
        stage = ResonanceChamberBlock.Stage.values()[Math.max(0, Math.min(3, tag.method_10550("Stage")))];
    }

    @Override protected void method_11007(class_2487 tag) {
        super.method_11007(tag);
        class_1262.method_5426(tag, items);
        tag.method_10569("Progress", progress);
        tag.method_10569("MaxProgress", maxProgress);
        tag.method_10569("Stage", stage.ordinal());
        tag.method_10569("StageTimer", stageTimer);
    }

    @Override public class_2487 method_16887() {
        class_2487 tag = new class_2487();
        method_11007(tag);
        return tag;
    }

    @Nullable @Override public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    @Override public int[] method_5494(class_2350 side) {
        return side == class_2350.field_11033 ? new int[]{1} : new int[]{0};
    }
    @Override public boolean method_5492(int slot, class_1799 stack, @Nullable class_2350 side) {
        return slot == 0 && ResonanceRecipes.find(stack) != null;
    }
    @Override public boolean method_5493(int slot, class_1799 stack, class_2350 side) { return slot == 1; }
    @Override public int method_5439() { return items.size(); }
    @Override public boolean method_5442() { return items.stream().allMatch(class_1799::method_7960); }
    @Override public class_1799 method_5438(int slot) { return items.get(slot); }
    @Override public class_1799 method_5434(int slot, int amount) {
        class_1799 result = class_1262.method_5430(items, slot, amount);
        if (!result.method_7960()) method_5431();
        return result;
    }
    @Override public class_1799 method_5441(int slot) { return items.set(slot, class_1799.field_8037); }
    @Override public void method_5447(int slot, class_1799 stack) {
        items.set(slot, stack);
        if (stack.method_7947() > method_5444()) stack.method_7939(method_5444());
        method_5431();
    }
    @Override public boolean method_5443(class_1657 player) {
        return field_11863 != null
                && field_11863.method_8321(field_11867) == this
                && player.method_5649(
                field_11867.method_10263() + 0.5,
                field_11867.method_10264() + 0.5,
                field_11867.method_10260() + 0.5) <= 64.0;
    }
    @Override public void method_5448() {
        items.clear();
        method_5431();
    }
    @Override public boolean method_5437(int slot, class_1799 stack) {
        return slot == 0 && ResonanceRecipes.find(stack) != null;
    }
    @Override public int method_5444() { return 64; }
    @Override public class_2561 method_5476() { return class_2561.method_43471("container.pocketdoor.resonance_chamber"); }
    @Override public class_1703 createMenu(int id, class_1661 inventory, class_1657 player) {
        return new ResonanceChamberMenu(id, inventory, this, data);
    }
}
