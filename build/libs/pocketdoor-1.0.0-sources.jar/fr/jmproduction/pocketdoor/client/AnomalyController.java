package fr.jmproduction.pocketdoor.client;

import fr.jmproduction.pocketdoor.network.ModMessages;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.class_1109;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import java.util.Random;

/** Client-only state machine for the Veilleur stellaire anomaly. */
public final class AnomalyController {
    private static final int FLUCTUATION_START = 60, DETECTION_START = 120;
    private static final int TRAVEL_TICKS = 150, ARRIVAL_TICK = DETECTION_START + TRAVEL_TICKS;
    private static final int SAFETY_TIMEOUT_TICKS = 20 * 20;
    private static boolean pending, started, returnRequested, meteoriteSent, markerArrived;
    private static int ticks = -1, returnWait, totalTicks;
    private static int targetSystem, targetPlanet;
    private static final Random TARGET_RANDOM = new Random();

    public static void arm() { pending=true; started=false; ticks=-1; returnRequested=false; returnWait=0; meteoriteSent=false; markerArrived=false; totalTicks=0; targetSystem=TARGET_RANDOM.nextInt(5); targetPlanet=TARGET_RANDOM.nextInt(4); }
    public static boolean isPending(){return pending;} public static int phaseTicks(){return ticks;}
    public static boolean isFluctuation(){return ticks>=FLUCTUATION_START&&ticks<DETECTION_START;} public static boolean isDetected(){return ticks>=DETECTION_START;}
    public static int targetSystem(){return targetSystem;} public static int targetPlanet(){return targetPlanet;} public static boolean markerArrived(){return markerArrived;}
    public static float markerProgress(){return ticks<DETECTION_START?0.0F:Math.min(1.0F,(ticks-DETECTION_START)/(float)TRAVEL_TICKS);}
    public static void onOverview(boolean overview,int selectedSystem){if(pending&&!started&&overview){started=true;ticks=0;markerArrived=false;}}
    public static void tick(class_310 mc){
        if (++totalTicks > SAFETY_TIMEOUT_TICKS) { CartostellaireClient.forceRelease(mc); reset(); return; }
        if(started&&ticks>=0&&ticks<ARRIVAL_TICK){ticks++; if(isFluctuation()&&ticks%5==0)play(mc,class_3417.field_14793,ticks%10==0?1.85F:1.55F); else if(isDetected()&&ticks%5==0)play(mc,(ticks/5)%2==0?class_3417.field_14624:class_3417.field_18310,(ticks/5)%2==0?.72F:.58F); if(ticks>=ARRIVAL_TICK)markerArrived=true;}
        if(started&&ticks>=ARRIVAL_TICK)markerArrived=true;
        if(returnRequested&&!CartostellaireClient.isRunning()&&returnWait>0&&--returnWait==0&&!meteoriteSent){meteoriteSent=true;ClientPlayNetworking.send(ModMessages.VEILLEUR_METEORITE,PacketByteBufs.empty());clearSequence();}
    }
    private static void play(class_310 mc,class_3414 sound,float pitch){mc.method_1483().method_4873(class_1109.method_4757(sound,pitch,1.0F));}
    public static void requestReturn(){if(!returnRequested&&(pending||started)){returnRequested=true;returnWait=30;pending=false;started=false;ticks=-1;markerArrived=true;}}
    private static void clearSequence(){pending=false;started=false;ticks=-1;returnRequested=false;returnWait=0;markerArrived=true;totalTicks=0;}
    public static void reset(){clearSequence();meteoriteSent=false;}
    public static void onMeteoriteFinished(class_310 mc){CartostellaireClient.forceRelease(mc);reset();}
    public static class_2561 message(){if(isDetected())return class_2561.method_43470("Anomalie détectée");if(isFluctuation())return class_2561.method_43470("Fluctuation détectée");return class_2561.method_43473();}
    private AnomalyController(){}
}
