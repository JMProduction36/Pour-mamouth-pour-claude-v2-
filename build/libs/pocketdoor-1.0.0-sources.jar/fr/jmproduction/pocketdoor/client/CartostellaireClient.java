package fr.jmproduction.pocketdoor.client;

import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_304;
import net.minecraft.class_310;

/** Client-only cinematic controller. The server remains authoritative for activation. */
public final class CartostellaireClient {
    private static final int ASCENT_TICKS = 200;
    private static final int RETURN_SPEED = 8;
    private static final double MAX_HEIGHT_ABOVE_BLOCK = 400.0D;
    private static int ticks;
    private static boolean running;
    private static boolean returning;
    private static class_243 origin = class_243.field_1353;
    private static double maximumCameraY;
    private static float originYaw;
    private static float originPitch;
    private static boolean previousHideGui;
    private static boolean anomalyArmed;
    public static void armAnomaly() { anomalyArmed = true; }
    public static boolean consumeAnomaly() { boolean v=anomalyArmed; anomalyArmed=false; return v; }

    public static void start(class_2338 cartostellairePos) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || running || cartostellairePos == null) return;
        origin = class_243.method_24953(cartostellairePos);
        maximumCameraY = cartostellairePos.method_10264() + MAX_HEIGHT_ABOVE_BLOCK;
        originYaw = mc.field_1724.method_36454();
        originPitch = mc.field_1724.method_36455();
        previousHideGui = mc.field_1690.field_1842;
        mc.field_1690.field_1842 = true;
        ticks = 0;
        returning = false;
        running = true;
        freezePlayer(mc);
    }

    public static void tick(class_310 mc) {
        if (!running) return;
        if (mc.field_1724 == null) {
            resetState(mc);
            return;
        }
        freezePlayer(mc);
        if (!returning && ticks < ASCENT_TICKS) ticks++;
        else if (returning && ticks > 0) {
            ticks = Math.max(0, ticks - RETURN_SPEED);
            if (ticks == 0) stop(mc);
        }
        if (!returning && ticks >= ASCENT_TICKS && mc.field_1755 == null)
            mc.method_1507(new CartostellaireScreen());
    }

    /** Reassert all movement state every tick; this also clears queued key presses. */
    private static void freezePlayer(class_310 mc) {
        if (mc.field_1724 == null) return;
        setDown(mc.field_1690.field_1894, false); setDown(mc.field_1690.field_1881, false);
        setDown(mc.field_1690.field_1913, false); setDown(mc.field_1690.field_1849, false);
        setDown(mc.field_1690.field_1903, false); setDown(mc.field_1690.field_1832, false);
        setDown(mc.field_1690.field_1867, false); setDown(mc.field_1690.field_1886, false);
        setDown(mc.field_1690.field_1904, false); setDown(mc.field_1690.field_1822, false);
        setDown(mc.field_1690.field_1869, false); setDown(mc.field_1690.field_1831, false);
        setDown(mc.field_1690.field_1871, false);
        for (class_304 key : mc.field_1690.field_1852) setDown(key, false);
        mc.field_1724.field_3913.field_3905 = 0.0F;
        mc.field_1724.field_3913.field_3907 = 0.0F;
        mc.field_1724.field_3913.field_3904 = false;
        mc.field_1724.field_3913.field_3903 = false;
        mc.field_1724.method_18799(class_243.field_1353);
        mc.field_1724.method_36456(originYaw);
        mc.field_1724.method_36457(originPitch);
        mc.field_1724.method_5847(originYaw);
        mc.field_1724.field_5982 = originYaw;
        mc.field_1724.field_6004 = originPitch;
        mc.field_1724.field_5960 = true;
    }

    private static void setDown(class_304 key, boolean down) { key.method_23481(down); }

    public static void beginReturn() { if (running) returning = true; }
    public static boolean isRunning() { return running; }

    private static double progress(float partialTick) {
        double value = returning ? (ticks - partialTick) / (double) ASCENT_TICKS
                : (ticks - 1.0D + partialTick) / (double) ASCENT_TICKS;
        return Math.max(0.0D, Math.min(1.0D, value));
    }
    private static double easeOutCubic(double value) { return 1.0D - Math.pow(1.0D - value, 3.0D); }
    public static class_243 cameraPosition(float partialTick) {
        if (!running) return null;
        double eased = easeOutCubic(progress(partialTick));
        return new class_243(origin.field_1352, Math.min(maximumCameraY, origin.field_1351 + MAX_HEIGHT_ABOVE_BLOCK * eased), origin.field_1350);
    }
    public static float cameraPitch(float partialTick) { return running ? 90.0F : originPitch; }
    public static float cameraYaw() { return originYaw; }

    private static void stop(class_310 mc) { resetState(mc); }

    /** Called when the client disconnects so cinematic state cannot leak into a later world. */
    public static void reset(class_310 mc) { resetState(mc); }

    private static void resetState(class_310 mc) {
        running = false; returning = false; ticks = 0;
        if (mc.field_1724 != null) { mc.field_1724.field_5960 = false; mc.field_1724.method_18799(class_243.field_1353); }
        mc.field_1690.field_1842 = previousHideGui;
    }
    private CartostellaireClient() {}
}
