package fr.jmproduction.pocketdoor.client;

import fr.jmproduction.pocketdoor.PocketDoorMod;
import fr.jmproduction.pocketdoor.network.ModMessages;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.class_1109;
import net.minecraft.class_1113.class_1114;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import net.minecraft.class_5481;
import net.minecraft.class_5819;
import java.util.List;

public final class DialogueController extends class_437 {
    private static final String[][] SPEECH = {
            {"Tiens,", "tiens,", "tiens...", "un dokipa..."},
            {"Qui je suis?"},
            {"Hmph...", "Si jeune,", "si naif."},
            {"Rendez la moi."},
            {"Rendez la moi."},
            {"Rendez la moi!!!"}
    };

    private static final String[] RESPONSES = {
            "Qui êtes vous ?",
            "Qui êtes vous?",
            "De quoi parlez vous?",
            "Qui êtes vous ?",
            "Qui êtes vous ?",
            ""
    };

    private static final int[] AUDIO_TICKS = {150, 65, 149, 71, 70, 72};

    private static final class_3414[] VOICE = {
            PocketDoorMod.REPLIQUE_1_SILGO,
            PocketDoorMod.REPLIQUE_2_SILGO,
            PocketDoorMod.REPLIQUE_3_SILGO,
            PocketDoorMod.REPLIQUE_4_SILGO,
            PocketDoorMod.REPLIQUE_5_SILGO,
            PocketDoorMod.REPLIQUE_6_SILGO
    };

    private static DialogueController current;
    private int line;
    private int remaining;
    private class_4185 responseButton;

    private DialogueController() {
        super(class_2561.method_43470("Pocket Door"));
        line = 0;
        remaining = AUDIO_TICKS[0];
        responseButton = null;
    }

    public static void start() {
        if (current != null) {
            return;
        }
        current = new DialogueController();
        class_310.method_1551().method_1507(current);
        current.startAudio();
    }

    private void startAudio() {
        remaining = AUDIO_TICKS[line];
        class_310.method_1551().method_1483().method_4873(new class_1109(
                VOICE[line].method_14833(),
                class_3419.field_15256,
                1.0F,
                1.0F,
                class_5819.method_43047(),
                false,
                0,
                class_1114.field_5478,
                0.0F,
                0.0F,
                0.0F,
                true
        ));
        updateButtonState();
    }

    @Override
    protected void method_25426() {
        responseButton = null;
        if (line < RESPONSES.length - 1) {
            responseButton = method_37063(new class_4185(
                    field_22789 / 2 - 100,
                    field_22790 - 55,
                    200,
                    20,
                    class_2561.method_43470(RESPONSES[line]),
                    button -> chooseResponse()
            ));
            updateButtonState();
        }
    }

    private void updateButtonState() {
        if (responseButton != null) {
            responseButton.field_22763 = remaining <= 0;
            responseButton.field_22764 = remaining <= 0;
        }
    }

    private void chooseResponse() {
        if (responseButton == null || !responseButton.field_22763) {
            return;
        }
        line++;
        remaining = AUDIO_TICKS[line];
        method_37067();
        method_25426();
        startAudio();
    }

    @Override
    public void method_25393() {
        if (remaining > 0) {
            remaining--;
            updateButtonState();
            if (remaining == 0 && line == AUDIO_TICKS.length - 1) {
                finish();
            }
        }
    }

    private void finish() {
        ClientPlayNetworking.send(ModMessages.DIALOGUE_FINISHED, PacketByteBufs.empty());
        current = null;
        class_310.method_1551().method_1507(null);
    }

    private String getCurrentSegment() {
        String[] segments = SPEECH[line];
        if (segments.length == 1) {
            return segments[0];
        }

        int totalWeight = 0;
        for (String segment : segments) {
            totalWeight += Math.max(1, segment.length());
        }

        int elapsed = Math.max(0, AUDIO_TICKS[line] - remaining);
        int cumulative = 0;
        for (String segment : segments) {
            cumulative += Math.max(1, (int) Math.ceil(
                    (double) AUDIO_TICKS[line] * Math.max(1, segment.length()) / totalWeight));
            if (elapsed < cumulative) {
                return segment;
            }
        }
        return segments[segments.length - 1];
    }

    @Override
    public void method_25394(class_4587 poseStack, int mouseX, int mouseY, float partialTick) {
        super.method_25394(poseStack, mouseX, mouseY, partialTick);

        class_2561 title = class_2561.method_43470(getCurrentSegment())
                .method_27694(style -> style.method_10982(true).method_10977(class_124.field_1078));
        int availableWidth = Math.max(1, field_22789 - 40);
        int regionTop = 8;
        int regionBottom = Math.max(9, field_22790 - 67);
        int heightAvail = regionBottom - regionTop;
        List<class_5481> lines = field_22793.method_1728(title, Math.max(1, availableWidth / 4));
        int widest = 1;
        for (class_5481 line : lines) {
            widest = Math.max(widest, field_22793.method_30880(line));
        }
        int blockHeight = Math.max(1, lines.size() * field_22793.field_2000);
        float scale = Math.min(4.0F, Math.min(
                availableWidth / (float) widest,
                heightAvail / (float) blockHeight));
        float top = Math.max(regionTop, Math.min(
                regionBottom - blockHeight * scale,
                (field_22790 - blockHeight * scale) / 2.0F - 20.0F));

        poseStack.method_22903();
        poseStack.method_22904(field_22789 / 2.0F, top, 0.0F);
        poseStack.method_22905(scale, scale, scale);
        for (int index = 0; index < lines.size(); index++) {
            class_5481 line = lines.get(index);
            field_22793.method_27517(poseStack, line, -field_22793.method_30880(line) / 2.0F,
                    index * field_22793.field_2000, 0x5555FF);
        }
        poseStack.method_22909();
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    public boolean method_25422() {
        return false;
    }
}