package fr.jmproduction.pocketdoor.client;

import fr.jmproduction.pocketdoor.PocketDoorMod;
import fr.jmproduction.pocketdoor.network.ModMessages;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1109;
import net.minecraft.class_1113.class_1114;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import net.minecraft.class_5819;

public final class DialogueController extends class_437 {
 private static final String[] SPEECH={"Tiens, tiens, tiens... un dokipa...","Qui je suis?","Hmph... Si jeune, si naif.","Rendez la moi.","Rendez la moi.","Rendez la moi!!!"};
 private static final String[] RESPONSES={"Qui êtes vous ?","Qui êtes vous?","De quoi parlez vous?","Qui êtes vous ?","Qui êtes vous ?",""};
 private static final int[] AUDIO_TICKS={150,65,149,71,70,72};
 private static final class_3414[] VOICE={PocketDoorMod.REPLIQUE_1_SILGO,PocketDoorMod.REPLIQUE_2_SILGO,PocketDoorMod.REPLIQUE_3_SILGO,PocketDoorMod.REPLIQUE_4_SILGO,PocketDoorMod.REPLIQUE_5_SILGO,PocketDoorMod.REPLIQUE_6_SILGO};
 private static DialogueController current; private int line,audioTicksRemaining; private class_4185 responseButton;
 private DialogueController(){super(class_2561.method_43470("Pocket Door"));}
 public static void start(){if(current!=null)return; current=new DialogueController(); class_310.method_1551().method_1507(current); current.startAudio();}
 private void startAudio(){audioTicksRemaining=AUDIO_TICKS[line]; class_310 mc=class_310.method_1551(); mc.field_1705.method_34001(0,audioTicksRemaining,0); mc.field_1705.method_34004(class_2561.method_43470(SPEECH[line]).method_27694(s->s.method_10982(true).method_10977(class_124.field_1078))); mc.method_1483().method_4873(new class_1109(VOICE[line].method_14833(),class_3419.field_15256,1F,1F,class_5819.method_43047(),false,0,class_1114.field_5478,0F,0F,0F,true)); updateButtonState();}
 @Override protected void method_25426(){responseButton=null; if(line<RESPONSES.length-1){responseButton=method_37063(new class_4185(field_22789/2-100,field_22790-55,200,20,class_2561.method_43470(RESPONSES[line]),b->chooseResponse())); updateButtonState();}}
 private void updateButtonState(){if(responseButton!=null)responseButton.field_22763=audioTicksRemaining<=0;}
 private void chooseResponse(){if(audioTicksRemaining>0||line>=RESPONSES.length-1)return; line++; method_37067(); method_25426(); startAudio();}
 @Override public void method_25393(){if(audioTicksRemaining>0){audioTicksRemaining--;updateButtonState();if(audioTicksRemaining==0&&line==SPEECH.length-1)finish();}}
 private void finish(){class_310 mc=class_310.method_1551();mc.field_1705.method_34004(class_2561.method_43473());ClientPlayNetworking.send(ModMessages.DIALOGUE_FINISHED,net.fabricmc.fabric.api.networking.v1.PacketByteBufs.empty());current=null;mc.method_1507(null);}
 @Override public void method_25394(class_4587 p,int x,int y,float d){super.method_25394(p,x,y,d);}
 @Override public boolean method_25421(){return false;} @Override public boolean method_25422(){return false;}
}
