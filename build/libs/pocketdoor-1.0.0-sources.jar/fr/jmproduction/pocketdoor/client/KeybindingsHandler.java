package fr.jmproduction.pocketdoor.client;

import fr.jmproduction.pocketdoor.network.ModMessages;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.class_304;
import org.lwjgl.glfw.GLFW;

public class KeybindingsHandler implements ClientModInitializer {
    public static class_304 OPEN;
    public static class_304 METEORITE;

    @Override
    public void onInitializeClient() {
        OPEN = KeyBindingHelper.registerKeyBinding(new class_304("key.pocketdoor.open", GLFW.GLFW_KEY_U, "category.pocketdoor"));
        METEORITE = KeyBindingHelper.registerKeyBinding(new class_304("key.pocketdoor.meteorite", GLFW.GLFW_KEY_M, "category.pocketdoor"));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            AnomalyController.tick(client);
            while (OPEN.method_1436()) ClientPlayNetworking.send(ModMessages.OPEN_POCKET_DOOR, PacketByteBufs.empty());
            while (METEORITE.method_1436()) {
                if (client.field_1724 != null) client.field_1724.method_7353(net.minecraft.class_2561.method_43470("[Pocket Door] M détectée : envoi du paquet météorite…"), true);
                ClientPlayNetworking.send(ModMessages.SUMMON_METEORITE, PacketByteBufs.empty());
            }
        });
        ClientPlayNetworking.registerGlobalReceiver(ModMessages.VEILLEUR_ANOMALY,(client,handler,buf,response)->client.execute(AnomalyController::arm)); ClientPlayNetworking.registerGlobalReceiver(ModMessages.START_DIALOGUE, (client, handler, buf, responseSender) -> client.execute(DialogueController::start));
    }
}
