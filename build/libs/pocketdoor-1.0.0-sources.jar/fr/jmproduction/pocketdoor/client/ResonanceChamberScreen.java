package fr.jmproduction.pocketdoor.client;

import com.mojang.blaze3d.systems.RenderSystem;
import fr.jmproduction.pocketdoor.menu.ResonanceChamberMenu;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_465;
import net.minecraft.class_757;

public class ResonanceChamberScreen extends class_465<ResonanceChamberMenu> {
    private static final class_2960 TEX = new class_2960("pocketdoor", "textures/gui/resonance_chamber.png");
    private static final int TEXTURE_WIDTH = 256;
    private static final int TEXTURE_HEIGHT = 200;

    public ResonanceChamberScreen(ResonanceChamberMenu menu, class_1661 inventory, class_2561 title) {
        super(menu, inventory, title);
        field_2792 = TEXTURE_WIDTH;
        field_2779 = TEXTURE_HEIGHT;
        field_25267 = 0;
        field_25268 = 0;
        field_25269 = 0;
        field_25270 = 0;
    }

    @Override
    protected void method_2389(class_4587 poseStack, float partialTick, int mouseX, int mouseY) {
        int left = (field_22789 - field_2792) / 2;
        int top = (field_22790 - field_2779) / 2;
        RenderSystem.setShader(class_757::method_34542);
        RenderSystem.setShaderTexture(0, TEX);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        class_332.method_25290(poseStack, left, top, 0, 0, TEXTURE_WIDTH, TEXTURE_HEIGHT, TEXTURE_WIDTH, TEXTURE_HEIGHT);
        int max = field_2797.maxProgress();
        if (max > 0) {
            int filled = Math.min(29, 29 * field_2797.progress() / max);
            // Kept in the upper control band, clear of the altar and inventory artwork.
            class_332.method_25294(poseStack, left + 107, top + 20, left + 136, top + 23, 0x5536d9e8);
            class_332.method_25294(poseStack, left + 107, top + 20, left + 107 + filled, top + 23, 0xff36d9e8);
        }
    }

    @Override
    protected void method_2388(class_4587 poseStack, int mouseX, int mouseY) {
        // The artwork contains its own labels; keep the dynamic label in the top band.
        if (field_2797.stage() > 0) {
            field_22793.method_1729(poseStack, "RESONANCE", 101, 28, 0xff9debf2);
        }
    }

    @Override
    public void method_25394(class_4587 poseStack, int mouseX, int mouseY, float partialTick) {
        method_25420(poseStack);
        super.method_25394(poseStack, mouseX, mouseY, partialTick);
        method_2380(poseStack, mouseX, mouseY);
    }
}
