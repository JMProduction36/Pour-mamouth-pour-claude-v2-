package fr.jmproduction.pocketdoor.client;
import fr.jmproduction.pocketdoor.Content;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.class_3929;
public final class ResonanceClient implements ClientModInitializer {
 @Override public void onInitializeClient(){ class_3929.method_17542(Content.RESONANCE_CHAMBER_MENU, ResonanceChamberScreen::new); }
}
