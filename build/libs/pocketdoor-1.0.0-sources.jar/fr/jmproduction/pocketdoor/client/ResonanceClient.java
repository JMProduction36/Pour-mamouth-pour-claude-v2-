package fr.jmproduction.pocketdoor.client;

import fr.jmproduction.pocketdoor.Content;
import fr.jmproduction.pocketdoor.item.PapierFoudreItem;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.class_1657;
import net.minecraft.class_2960;
import net.minecraft.class_3929;
import net.minecraft.class_5272;
import net.minecraft.class_953;

public final class ResonanceClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        class_3929.method_17542(Content.RESONANCE_CHAMBER_MENU, ResonanceChamberScreen::new);
        EntityRendererRegistry.register(Content.PAPIER_FOUDRE_PROJECTILE, class_953::new);
        class_5272.method_27879(
                Content.PAPIER_FOUDRE,
                new class_2960("pocketdoor", "charge"),
                (stack, level, entity, seed) -> entity instanceof class_1657 player
                        ? PapierFoudreItem.charge(stack, level, player)
                        : 0.0F
        );
    }
}
