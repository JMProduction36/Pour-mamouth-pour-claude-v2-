package fr.jmproduction.pocketdoor.data;
import java.util.*;
import net.minecraft.class_18;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_3218;
import net.minecraft.nbt.*;
public class PocketDoorSavedData extends class_18 {private final Set<UUID> finished=new HashSet<>(); public static PocketDoorSavedData get(class_3218 l){return l.method_17983().method_17924(PocketDoorSavedData::load,PocketDoorSavedData::new,"pocketdoor_dialogue");} public static PocketDoorSavedData load(class_2487 t){PocketDoorSavedData d=new PocketDoorSavedData();class_2499 x=t.method_10554("finished",8);for(int i=0;i<x.size();i++)try{d.finished.add(UUID.fromString(x.method_10608(i)));}catch(IllegalArgumentException ignored){}return d;} public boolean isFinished(UUID u){return finished.contains(u);} public void markFinished(UUID u){if(finished.add(u))method_80();} @Override public class_2487 method_75(class_2487 t){class_2499 x=new class_2499();finished.forEach(u->x.add(class_2519.method_23256(u.toString())));t.method_10566("finished",x);return t;}}
