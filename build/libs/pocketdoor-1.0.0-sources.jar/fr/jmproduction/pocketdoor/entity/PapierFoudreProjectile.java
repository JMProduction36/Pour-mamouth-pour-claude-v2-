package fr.jmproduction.pocketdoor.entity;

import fr.jmproduction.pocketdoor.Content;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1538;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2604;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3857;
import net.minecraft.class_5425;

public class PapierFoudreProjectile extends class_3857 {
    public PapierFoudreProjectile(class_1299<? extends PapierFoudreProjectile> type, class_1937 level) {
        super(type, level);
    }

    public PapierFoudreProjectile(class_1937 level, class_1309 owner) {
        super(Content.PAPIER_FOUDRE_PROJECTILE, owner, level);
    }

    @Override
    public class_2596<class_2602> method_18002() {
        return new class_2604(this);
    }

    @Override
    protected class_1792 method_16942() {
        return Content.PAPIER_FOUDRE;
    }

    @Override
    public class_1799 method_7495() {
        class_1799 stack = super.method_7495();
        stack.method_7948().method_10569("CustomModelData", 1);
        return stack;
    }

    @Override
    protected void method_7488(class_239 result) {
        super.method_7488(result);
        if (!field_6002.field_9236 && field_6002 instanceof class_5425) {
            class_2338 impact = method_24515();
            class_1538 lightning = class_1299.field_6112.method_5883(field_6002);
            if (lightning != null) {
                lightning.method_24203(impact.method_10263() + 0.5D, impact.method_10264(), impact.method_10260() + 0.5D);
                lightning.method_29498(false);
                field_6002.method_8649(lightning);
            }
            if (method_24921() instanceof class_1657 player && !player.method_31549().field_7477) {
                player.method_6047().method_7934(1);
            }
            field_6002.method_43128(null, method_23317(), method_23318(), method_23321(), class_3417.field_14865,
                    class_3419.field_15252, 5.0F, 1.0F);
            method_31472();
        }
    }
}
