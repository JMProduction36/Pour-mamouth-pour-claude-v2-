package fr.jmproduction.pocketdoor.item;

import fr.jmproduction.pocketdoor.Content;
import fr.jmproduction.pocketdoor.entity.PapierFoudreProjectile;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1839;
import net.minecraft.class_1937;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

public class PapierFoudreItem extends class_1792 {
    public static final int CHARGE_TICKS = 30;
    public static final int MAX_USE_DURATION = 72000;

    public PapierFoudreItem(class_1793 properties) {
        super(properties);
    }

    @Override
    public class_1839 method_7853(class_1799 stack) {
        return class_1839.field_8953;
    }

    @Override
    public int method_7881(class_1799 stack) {
        return MAX_USE_DURATION;
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        player.method_6019(hand);
        return class_1271.method_22428(player.method_5998(hand));
    }

    @Override
    public void method_7840(class_1799 stack, class_1937 level, class_1309 entity, int timeLeft) {
        if (!(entity instanceof class_1657 player) || level.field_9236) {
            return;
        }
        int usedTicks = MAX_USE_DURATION - timeLeft;
        if (usedTicks < CHARGE_TICKS) {
            return;
        }

        PapierFoudreProjectile projectile = new PapierFoudreProjectile(level, player);
        class_1799 projectileStack = new class_1799(Content.PAPIER_FOUDRE);
        projectileStack.method_7948().method_10569("CustomModelData", 1);
        projectile.method_16940(projectileStack);
        projectile.method_24919(player, player.method_36455(), player.method_36454(), 0.0F, 1.5F, 1.0F);
        level.method_8649(projectile);
        level.method_43128(null, player.method_23317(), player.method_23318(), player.method_23321(),
                class_3417.field_14873, class_3419.field_15248,
                0.5F, 0.4F / (level.method_8409().method_43057() * 0.4F + 0.8F));

        if (!player.method_31549().field_7477) {
            stack.method_7934(1);
        }
    }

    public static float charge(class_1799 stack, class_1937 level, class_1657 player) {
        if (!player.method_6115() || player.method_6030() != stack) {
            return 0.0F;
        }
        int usedTicks = MAX_USE_DURATION - player.method_6014();
        if (usedTicks >= CHARGE_TICKS) return 1.0F;
        if (usedTicks >= 20) return 0.6666667F;
        if (usedTicks >= 10) return 0.33333334F;
        return 0.0F;
    }
}