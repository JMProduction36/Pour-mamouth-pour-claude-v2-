package fr.jmproduction.pocketdoor.menu;

import fr.jmproduction.pocketdoor.Content;
import fr.jmproduction.pocketdoor.recipe.ResonanceRecipes;
import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_3913;
import net.minecraft.class_3919;

public class ResonanceChamberMenu extends class_1703 {
    // Slot coordinates are the top-left of the 16x16 item area; the rendered slot border is x-1,y-1.
    // The 18x18 rectangles are centered in the two 32px inner frame openings.
    private static final int INPUT_X = 36, OUTPUT_X = 191, MACHINE_Y = 53;
    // 9*18 = 162px, centered in the 256px artwork: (256-162)/2 = 47.
    private static final int INV_X = 47, INV_Y = 117, HOTBAR_Y = 171, SLOT_STEP = 18;
    private final class_1263 container;
    private final class_3913 data;

    public ResonanceChamberMenu(int id, class_1661 inventory) { this(id, inventory, new class_1277(2), new class_3919(4)); }
    public ResonanceChamberMenu(int id, class_1661 inventory, class_1263 container, class_3913 data) {
        super(Content.RESONANCE_CHAMBER_MENU, id); this.container=container; this.data=data; method_17359(container,2);
        method_7621(new class_1735(container,0,INPUT_X,MACHINE_Y) { @Override public boolean method_7680(class_1799 s) { return ResonanceRecipes.find(s)!=null; } });
        method_7621(new class_1735(container,1,OUTPUT_X,MACHINE_Y) { @Override public boolean method_7680(class_1799 s) { return false; } });
        for(int row=0;row<3;row++) for(int col=0;col<9;col++) method_7621(new class_1735(inventory,col+row*9+9,INV_X+col*SLOT_STEP,INV_Y+row*SLOT_STEP));
        for(int col=0;col<9;col++) method_7621(new class_1735(inventory,col,INV_X+col*SLOT_STEP,HOTBAR_Y));
        method_17360(data);
    }
    @Override public class_1799 method_7601(class_1657 player,int index) {
        if(index<0||index>=field_7761.size()||!field_7761.get(index).method_7681()) return class_1799.field_8037;
        class_1735 slot=field_7761.get(index); class_1799 result=slot.method_7677().method_7972();
        boolean moved=index<2?method_7616(result,2,field_7761.size(),true):method_7616(result,0,1,false);
        if(!moved)return class_1799.field_8037; slot.method_7673(result.method_7960()?class_1799.field_8037:result); if(!result.method_7960())slot.method_7668(); return result;
    }
    @Override public boolean method_7597(class_1657 player){return container.method_5443(player);}
    public int progress(){return data.method_17390(0);} public int maxProgress(){return data.method_17390(1);} public int stage(){return data.method_17390(2);}
}
