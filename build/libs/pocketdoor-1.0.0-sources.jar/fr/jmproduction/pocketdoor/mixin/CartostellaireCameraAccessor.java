package fr.jmproduction.pocketdoor.mixin;

import net.minecraft.class_243;
import net.minecraft.class_4184;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_4184.class)
public interface CartostellaireCameraAccessor {
    @Invoker("setPosition")
    void pocketdoor$setPosition(class_243 position);

    @Invoker("setRotation")
    void pocketdoor$setRotation(float yRot, float xRot);

    @Accessor("detached")
    void pocketdoor$setDetached(boolean detached);
}
