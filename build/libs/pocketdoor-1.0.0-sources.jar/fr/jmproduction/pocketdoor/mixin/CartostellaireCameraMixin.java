package fr.jmproduction.pocketdoor.mixin;

import fr.jmproduction.pocketdoor.client.CartostellaireClient;
import net.minecraft.class_1297;
import net.minecraft.class_1922;
import net.minecraft.class_243;
import net.minecraft.class_4184;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Applies the cinematic after vanilla Camera.setup, so vanilla cannot overwrite it. */
@Mixin(class_4184.class)
public final class CartostellaireCameraMixin {
    @Inject(method = "setup", at = @At("TAIL"), require = 0)
    private void pocketdoor$camera(class_1922 level, class_1297 entity, boolean detached, boolean mirror,
                                   float partialTick, CallbackInfo ci) {
        class_243 position = CartostellaireClient.cameraPosition(partialTick);
        if (position == null) return;
        CartostellaireCameraAccessor camera = (CartostellaireCameraAccessor) (Object) this;
        camera.pocketdoor$setDetached(true);
        camera.pocketdoor$setPosition(position);
        camera.pocketdoor$setRotation(CartostellaireClient.cameraYaw(),
                CartostellaireClient.cameraPitch(partialTick));
    }
}
