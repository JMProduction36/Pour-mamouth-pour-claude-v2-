package fr.jmproduction.pocketdoor.mixin;

import fr.jmproduction.pocketdoor.client.CartostellaireClient;
import net.minecraft.class_329;
import net.minecraft.class_4587;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Prevents hotbar, crosshair and other in-game HUD elements during the shot. */
@Mixin(class_329.class)
public final class CartostellaireGuiMixin {
    @Inject(method = "render", at = @At("HEAD"), cancellable = true, require = 0)
    private void pocketdoor$hideHud(class_4587 poseStack, float partialTick, CallbackInfo ci) {
        if (CartostellaireClient.isRunning()) ci.cancel();
    }
}
