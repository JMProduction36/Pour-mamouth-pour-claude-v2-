package fr.jmproduction.pocketdoor.mixin;

import net.minecraft.class_312;
import org.spongepowered.asm.mixin.Mixin;

/** Intentionally empty: the anomaly never captures mouse rotation or scrolling. */
@Mixin(class_312.class)
public final class CartostellaireMouseHandlerMixin {
    private CartostellaireMouseHandlerMixin() {}
}
