package fr.jmproduction.pocketdoor.network;

import fr.jmproduction.pocketdoor.PocketDoorMod;
import fr.jmproduction.pocketdoor.data.PocketDoorSavedData;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1294;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2398;
import net.minecraft.class_2902;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.ArrayList;
import java.util.List;

public final class ModMessages {
    public static final class_2960 OPEN_POCKET_DOOR = id("open_pocket_door");
    public static final class_2960 START_DIALOGUE = id("start_dialogue");
    public static final class_2960 DIALOGUE_FINISHED = id("dialogue_finished");

    private static final List<Pending> PENDING = new ArrayList<>();

    private record Pending(class_3222 player, int ticks) {
    }

    private static class_2960 id(String path) {
        return new class_2960(PocketDoorMod.MOD_ID, path);
    }

    public static void registerC2SPackets() {
        ServerPlayNetworking.registerGlobalReceiver(
                OPEN_POCKET_DOOR,
                (server, player, handler, buffer, responseSender) -> server.execute(
                        () -> PENDING.add(new Pending(player, 60))
                )
        );

        ServerPlayNetworking.registerGlobalReceiver(
                DIALOGUE_FINISHED,
                (server, player, handler, buffer, responseSender) -> server.execute(
                        () -> {
                            PocketDoorSavedData.get(player.method_14220()).markFinished(player.method_5667());
                            player.method_6016(class_1294.field_38092);
                        }
                )
        );

        ServerTickEvents.END_SERVER_TICK.register(ModMessages::tick);
    }

    private static void tick(MinecraftServer server) {
        for (int index = PENDING.size() - 1; index >= 0; index--) {
            Pending pending = PENDING.get(index);

            if (pending.ticks() <= 1) {
                place(pending.player());
                PENDING.remove(index);
            } else {
                PENDING.set(index, new Pending(pending.player(), pending.ticks() - 1));
            }
        }
    }

    private static void place(class_3222 player) {
        class_3218 level = player.method_14220();
        class_2350 facing = player.method_5735().method_10153();
        class_2338 position = player.method_24515().method_10079(player.method_5735(), 6);
        position = new class_2338(
                position.method_10263(),
                level.method_8624(class_2902.class_2903.field_13197, position.method_10263(), position.method_10260()),
                position.method_10260()
        );

        level.method_8652(
                position,
                PocketDoorMod.POCKET_DOOR.method_9564().method_11657(
                        class_2383.field_11177,
                        facing
                ),
                3
        );
        level.method_14199(
                class_2398.field_11240,
                position.method_10263() + 0.5,
                position.method_10264() + 1,
                position.method_10260() + 0.5,
                12,
                0.3,
                0.5,
                0.3,
                0.02
        );
    }

    public static boolean isFinished(class_3222 player) {
        return PocketDoorSavedData.get(player.method_14220()).isFinished(player.method_5667());
    }

    public static void sendStartDialogue(class_3222 player) {
        ServerPlayNetworking.send(player, START_DIALOGUE, PacketByteBufs.empty());
    }

    private ModMessages() {
    }
}