package fr.jmproduction.pocketdoor.network;

import fr.jmproduction.pocketdoor.PocketDoorMod;
import fr.jmproduction.pocketdoor.data.PocketDoorSavedData;
import fr.jmproduction.pocketdoor.world.MeteoriteManager;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2398;
import net.minecraft.class_2680;
import net.minecraft.class_2902;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.server.MinecraftServer;
import java.util.*;

public final class ModMessages {
    public static final class_2960 OPEN_POCKET_DOOR = id("open_pocket_door");
    public static final class_2960 START_DIALOGUE = id("start_dialogue");
    public static final class_2960 DIALOGUE_FINISHED = id("dialogue_finished");
    public static final class_2960 SUMMON_METEORITE = id("summon_meteorite");
    private static final Map<UUID, Integer> COOLDOWNS = new HashMap<>();
    private static final Set<UUID> ACTIVE_DIALOGUES = new HashSet<>();
    private static final List<Meteorite> METEORITES = new ArrayList<>();
    private static final List<Pending> PENDING = new ArrayList<>();
    private record Pending(class_3222 player, int ticks) {}
    private static final class Meteorite {
        final class_3222 player; final class_3218 level; final int x, z, groundY, radius;
        int centerY; final Map<class_2338, class_2680> originals = new HashMap<>(); final Set<class_2338> placed = new HashSet<>();
        Meteorite(class_3222 p, int x, int z, int groundY, int radius, int centerY) { this.player=p; this.level=p.method_14220(); this.x=x; this.z=z; this.groundY=groundY; this.radius=radius; this.centerY=centerY; }
    }
    private static class_2960 id(String path) { return new class_2960(PocketDoorMod.MOD_ID, path); }

    public static void registerC2SPackets() {
        ServerPlayNetworking.registerGlobalReceiver(SUMMON_METEORITE, (server, player, handler, buf, responseSender) -> server.execute(() -> MeteoriteManager.summon(player)));
        MeteoriteManager.register();
        ServerPlayNetworking.registerGlobalReceiver(OPEN_POCKET_DOOR, (server, player, handler, buf, responseSender) -> server.execute(() -> beginSequence(player)));
        ServerPlayNetworking.registerGlobalReceiver(DIALOGUE_FINISHED, (server, player, handler, buf, responseSender) -> server.execute(() -> {
            PocketDoorSavedData.get(player.method_14220()).markFinished(player.method_5667());
            player.method_6016(net.minecraft.class_1294.field_38092); player.method_6016(net.minecraft.class_1294.field_5919);
            ACTIVE_DIALOGUES.remove(player.method_5667());
        }));
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> server.execute(() -> cleanup(handler.method_32311().method_5667())));
        ServerTickEvents.END_SERVER_TICK.register(ModMessages::tick);
    }

    private static void cleanup(UUID id) {
        ACTIVE_DIALOGUES.remove(id); COOLDOWNS.remove(id); PENDING.removeIf(p -> p.player().method_5667().equals(id)); MeteoriteManager.disconnect(id);
        for (int i = METEORITES.size() - 1; i >= 0; i--) if (METEORITES.get(i).player.method_5667().equals(id)) { restore(METEORITES.remove(i)); }
    }
    private static void legacySummonMeteorite(class_3222 player) {
        UUID id = player.method_5667();
        if (ACTIVE_DIALOGUES.contains(id) || COOLDOWNS.getOrDefault(id, 0) > 0 || METEORITES.stream().anyMatch(m -> m.player.method_5667().equals(id))) return;
        class_2350 look = player.method_5735(); int x = player.method_24515().method_10263() + look.method_10148() * 20; int z = player.method_24515().method_10260() + look.method_10165() * 20;
        int ground = player.method_14220().method_8624(class_2902.class_2903.field_13203, x, z) - 1;
        Meteorite m = new Meteorite(player, x, z, ground, 7, ground + 7 + 70); COOLDOWNS.put(id, 20 * 15); place(m); METEORITES.add(m);
    }
    private static void tick(MinecraftServer server) {
        COOLDOWNS.replaceAll((id, n) -> Math.max(0, n - 1));
        for (int i = METEORITES.size() - 1; i >= 0; i--) { Meteorite m = METEORITES.get(i); int next = m.centerY - 1;
            if (!loaded(m, next)) continue;
            if (blocked(m, next)) { restore(m); impact(m); METEORITES.remove(i); }
            else if (next <= m.groundY + m.radius) { restore(m); impact(m); METEORITES.remove(i); }
            else { restore(m); m.centerY = next; place(m); }
        }
        for (int i=PENDING.size()-1;i>=0;i--) { Pending p=PENDING.get(i); if (p.ticks()<=1) { sendStartDialogue(p.player()); PENDING.remove(i); } else PENDING.set(i,new Pending(p.player(),p.ticks()-1)); }
    }
    private static boolean loaded(Meteorite m, int centerY) { return m.level.method_22340(new class_2338(m.x, centerY, m.z)); }
    private static boolean blocked(Meteorite m, int centerY) { int bottom=centerY-m.radius-1; class_2338 p=new class_2338(m.x,bottom,m.z); class_2680 state = m.level.method_8320(p); return !state.method_26215(); }
    private static void place(Meteorite m) { for(int dx=-m.radius;dx<=m.radius;dx++) for(int dy=-m.radius;dy<=m.radius;dy++) for(int dz=-m.radius;dz<=m.radius;dz++) if(dx*dx+dy*dy+dz*dz<=m.radius*m.radius) { class_2338 p=new class_2338(m.x+dx,m.centerY+dy,m.z+dz); if(!m.level.method_22340(p)) continue; m.originals.putIfAbsent(p,m.level.method_8320(p)); int d=dx*dx+dy*dy+dz*dz; m.level.method_8652(p,d<=4?class_2246.field_10540.method_9564():d<=24?class_2246.field_10092.method_9564():class_2246.field_23869.method_9564(),3); m.placed.add(p); } }
    private static void restore(Meteorite m) { for(Map.Entry<class_2338,class_2680> e:m.originals.entrySet()) if(m.level.method_22340(e.getKey())) m.level.method_8652(e.getKey(),e.getValue(),3); m.originals.clear(); m.placed.clear(); }
    private static void impact(Meteorite m) { m.centerY=m.groundY+m.radius; place(m); m.level.method_8396(null,new class_2338(m.x,m.groundY,m.z),class_3417.field_15152,class_3419.field_15245,2.0F,0.7F); m.level.method_14199(class_2398.field_11236,m.x+0.5,m.groundY+1,m.z+0.5,8,2,1,2,0.1); class_2350 facing=m.player.method_5735().method_10153(); class_2338 door=new class_2338(m.x,m.groundY+m.radius*2+1,m.z); m.level.method_8652(door,PocketDoorMod.POCKET_DOOR.method_9564().method_11657(class_2383.field_11177,facing),3); }
    public static void beginFromDoor(class_3222 player) { beginSequence(player); }
    private static void beginSequence(class_3222 player) { if(ACTIVE_DIALOGUES.add(player.method_5667())) PENDING.add(new Pending(player,100)); }
    public static boolean isFinished(class_3222 player) { return PocketDoorSavedData.get(player.method_14220()).isFinished(player.method_5667()); }
    public static void sendStartDialogue(class_3222 player) { ServerPlayNetworking.send(player,START_DIALOGUE,PacketByteBufs.empty()); }
    private ModMessages() {}
}
