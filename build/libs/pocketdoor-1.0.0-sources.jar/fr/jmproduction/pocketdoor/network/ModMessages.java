package fr.jmproduction.pocketdoor.network;

import fr.jmproduction.pocketdoor.PocketDoorMod;
import fr.jmproduction.pocketdoor.data.PocketDoorSavedData;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1540;
import net.minecraft.class_1927;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2540;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2756;
import net.minecraft.class_2806;
import net.minecraft.class_2902;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_5819;
import net.minecraft.server.MinecraftServer;
import java.util.*;

/** Server networking plus the server-authoritative meteorite event. */
public final class ModMessages {
    public static final class_2960 OPEN_POCKET_DOOR = id("open_pocket_door");
    public static final class_2960 START_DIALOGUE = id("start_dialogue");
    public static final class_2960 DIALOGUE_FINISHED = id("dialogue_finished");
    public static final class_2960 SUMMON_METEORITE = id("summon_meteorite");
    public static final class_2960 CARTOSTELLAIRE_START = id("cartostellaire_start");
    private static final Map<UUID, Integer> COOLDOWNS = new HashMap<>();
    private static final Set<UUID> ACTIVE_DIALOGUES = new HashSet<>();
    private static final List<Meteorite> METEORITES = new ArrayList<>();
    private static final List<ImpactAnimation> IMPACTS = new ArrayList<>();
    private static final List<Pending> PENDING = new ArrayList<>();
    private record Pending(class_3222 player, int ticks) {}

    private static final class Meteorite {
        final class_3222 player; final class_3218 level;
        final int x, z, groundY, radius, startX, startZ, startY, flightTicks;
        final double dx, dy, dz;
        int age;
        Meteorite(class_3222 p, int x, int z, int groundY, int radius, int startX, int startZ, int startY, int flightTicks) {
            this.player = p; this.level = (class_3218) p.method_14220(); this.x = x; this.z = z; this.groundY = groundY;
            this.radius = radius; this.startX = startX; this.startZ = startZ; this.startY = startY; this.flightTicks = flightTicks;
            this.dx = x - startX; this.dy = (groundY - radius / 2.0) - startY; this.dz = z - startZ;
        }
        double px() { return startX + dx * age / (double) flightTicks; }
        double py() { return startY + dy * age / (double) flightTicks; }
        double pz() { return startZ + dz * age / (double) flightTicks; }
    }

    private static final class ImpactAnimation {
        final class_3218 level; final class_3222 focus; final double x, y, z; int age;
        ImpactAnimation(class_3218 level, class_3222 focus, double x, double y, double z) { this.level = level; this.focus = focus; this.x = x; this.y = y; this.z = z; }
    }

    private static class_2960 id(String path) { return new class_2960(PocketDoorMod.MOD_ID, path); }

    public static void registerC2SPackets() {
        ServerPlayNetworking.registerGlobalReceiver(SUMMON_METEORITE, (server, player, handler, buf, responseSender) -> server.execute(() -> {
            // Deliberate receipt marker: proves that the client packet reached the server.
            player.method_43496(net.minecraft.class_2561.method_43470("Météorite invoquée"));
            summonMeteorite(player);
        }));
        ServerPlayNetworking.registerGlobalReceiver(OPEN_POCKET_DOOR, (server, player, handler, buf, responseSender) -> server.execute(() -> beginSequence(player)));
        ServerPlayNetworking.registerGlobalReceiver(DIALOGUE_FINISHED, (server, player, handler, buf, responseSender) -> server.execute(() -> {
            PocketDoorSavedData.get(player.method_14220()).markFinished(player.method_5667());
            player.method_6016(net.minecraft.class_1294.field_38092); player.method_6016(net.minecraft.class_1294.field_5919);
            ACTIVE_DIALOGUES.remove(player.method_5667());
        }));
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> server.execute(() -> cleanup(handler.method_32311().method_5667())));
        ServerTickEvents.END_SERVER_TICK.register(ModMessages::tick);
    }

    private static void cleanup(UUID id) {
        ACTIVE_DIALOGUES.remove(id); COOLDOWNS.remove(id); PENDING.removeIf(p -> p.player().method_5667().equals(id));
        METEORITES.removeIf(m -> m.player.method_5667().equals(id));
    }

    private static void summonMeteorite(class_3222 player) {
        UUID id = player.method_5667();
        if (ACTIVE_DIALOGUES.contains(id) || COOLDOWNS.getOrDefault(id, 0) > 0 || METEORITES.stream().anyMatch(m -> m.player.method_5667().equals(id))) return;
        class_5819 random = player.method_14220().field_9229;
        double angle = random.method_43058() * Math.PI * 2.0;
        int distance = 90 + random.method_43048(31);
        int x = class_3532.method_15357(player.method_23317() + Math.cos(angle) * distance);
        int z = class_3532.method_15357(player.method_23321() + Math.sin(angle) * distance);
        // The destination is intentionally outside the player's immediate view distance.
        // hasChunkAt(...) only tests whether it is already loaded; it does not load it.
        // The old early return therefore discarded almost every summon before METEORITES.add().
        class_3218 level = (class_3218) player.method_14220();
        level.method_14178().method_12121(x >> 4, z >> 4, class_2806.field_12803, true);
        int ground = level.method_8624(class_2902.class_2903.field_13203, x, z) - 1;
        int radius = 7 + random.method_43048(4);
        // The incoming line is a random diagonal, independent of the player's look direction.
        double travelAngle = angle + (random.method_43056() ? Math.PI : 0.0) + (random.method_43058() - 0.5) * 0.9;
        int offset = 112 + random.method_43048(17);
        int startX = class_3532.method_15357(x - Math.cos(travelAngle) * offset);
        int startZ = class_3532.method_15357(z - Math.sin(travelAngle) * offset);
        int startY = Math.min(level.method_31600() - 8, ground + 120);
        METEORITES.add(new Meteorite(player, x, z, ground, radius, startX, startZ, startY, 120 + random.method_43048(21)));
        COOLDOWNS.put(id, 20 * 15);
        player.method_43496(net.minecraft.class_2561.method_43470("Météorite en approche — trajectoire chargée."));
        level.method_8396(null, player.method_24515(), class_3417.field_14865, class_3419.field_15252, 12.0F, 0.65F);
    }

    private static void tick(MinecraftServer server) {
        COOLDOWNS.replaceAll((id, n) -> Math.max(0, n - 1));
        for (int i = METEORITES.size() - 1; i >= 0; i--) {
            Meteorite m = METEORITES.get(i);
            if (!m.player.method_5805() || m.player.method_14220() != m.level) { METEORITES.remove(i); continue; }
            double px = m.px(), py = m.py(), pz = m.pz();
            flightParticles(m, px, py, pz);
            m.age++;
            if (m.age >= m.flightTicks) { impact(m); METEORITES.remove(i); }
        }
        for (int i = IMPACTS.size() - 1; i >= 0; i--) {
            ImpactAnimation effect = IMPACTS.get(i); impactParticles(effect); effect.age++;
            if (effect.age > 36) IMPACTS.remove(i);
        }
        for (int i = PENDING.size() - 1; i >= 0; i--) { Pending p = PENDING.get(i); if (p.ticks() <= 1) { sendStartDialogue(p.player()); PENDING.remove(i); } else PENDING.set(i, new Pending(p.player(), p.ticks() - 1)); }
    }

    /** Sends directly to the triggering player so particles are visible even when the
     * trajectory is outside the normal server particle broadcast radius. */
    private static void sendParticles(class_3218 level, class_3222 focus, class_2394 particle,
                                       double x, double y, double z, int count,
                                       double dx, double dy, double dz, double speed) {
        for (class_3222 recipient : level.method_18456()) {
            if (recipient == focus || recipient.method_5649(x, y, z) <= 256.0 * 256.0) {
                level.method_14166(recipient, particle, true, x, y, z, count, dx, dy, dz, speed);
            }
        }
    }

    private static void flightParticles(Meteorite m, double x, double y, double z) {
        // A large, explicit particle core is used instead of a client-only visual entity:
        // it is reliable across 1.19.2 clients and is sent with overrideLimiter=true.
        class_243 direction = new class_243(m.dx, m.dy, m.dz).method_1029();
        class_243 side = Math.abs(direction.field_1351) < 0.92 ? direction.method_1036(new class_243(0, 1, 0)).method_1029()
                : direction.method_1036(new class_243(1, 0, 0)).method_1029();
        class_243 up = side.method_1036(direction).method_1029();
        class_5819 r = m.level.field_9229;
        // Four thick, wide rings: deliberately large while keeping each packet count modest.
        for (int ring = 0; ring < 6; ring++) {
            double radius = 3.0 + ring * 0.95;
            int points = 28 + ring * 6;
            double phase = m.age * 0.16 + ring * 0.7;
            for (int i = 0; i < points; i++) {
                double a = phase + (Math.PI * 2.0 * i / points);
                double wobble = 0.82 + r.method_43058() * 0.30;
                double ox = side.field_1352 * Math.cos(a) * radius * wobble + up.field_1352 * Math.sin(a) * radius * wobble;
                double oy = side.field_1351 * Math.cos(a) * radius * wobble + up.field_1351 * Math.sin(a) * radius * wobble;
                double oz = side.field_1350 * Math.cos(a) * radius * wobble + up.field_1350 * Math.sin(a) * radius * wobble;
                class_2394 kind = (i + ring + m.age) % 9 == 0 ? class_2398.field_11239
                        : ((i + m.age) % 7 == 0 ? class_2398.field_22246 : class_2398.field_11240);
                sendParticles(m.level, m.player, kind, x + ox, y + oy, z + oz, 1, .12, .12, .12, .015);
            }
        }
        // A much larger fireball core (all individual calls stay well below 600).
        sendParticles(m.level, m.player, class_2398.field_11240, x, y, z, 160, 2.4, 2.4, 2.4, .035);
        sendParticles(m.level, m.player, class_2398.field_22246, x, y, z, 80, 1.9, 1.9, 1.9, .028);
        sendParticles(m.level, m.player, class_2398.field_11239, x, y, z, 36, 1.65, 1.65, 1.65, 0.0);
        sendParticles(m.level, m.player, class_2398.field_11221, x, y, z, m.age % 5 == 0 ? 1 : 0, 0, 0, 0, 0);
        // Long, thick tail: several points behind the moving core, not only one puff.
        for (int i = 1; i <= 8; i++) {
            double tail = i * 2.35;
            sendParticles(m.level, m.player, class_2398.field_11237, x - direction.field_1352 * tail, y - direction.field_1351 * tail,
                    z - direction.field_1350 * tail, 6, 1.25 + i * .08, 1.25 + i * .08, 1.25 + i * .08, .022);
            if (i % 2 == 0) sendParticles(m.level, m.player, class_2398.field_22247, x - direction.field_1352 * tail,
                    y - direction.field_1351 * tail, z - direction.field_1350 * tail, 3, 1.5, 1.5, 1.5, .014);
        }
        if (m.age % 12 == 0) m.level.method_8396(null, new class_2338(class_3532.method_15357(x), class_3532.method_15357(y), class_3532.method_15357(z)),
                class_3417.field_15231, class_3419.field_15251, 8.0F, 0.7F + m.level.field_9229.method_43057() * 0.35F);
    }

    private static void impact(Meteorite m) {
        class_2338 center = new class_2338(m.x, class_3532.method_15357(m.groundY - m.radius * 0.45), m.z);
        // Keep the destination available for the impact tick too; otherwise the old
        // hasChunkAt guard could silently delete a meteorite at the end of flight.
        m.level.method_14178().method_12121(center.method_10263() >> 4, center.method_10260() >> 4, class_2806.field_12803, true);
        carveCrater(m, center);
        buildBody(m, center);
        launchDebris(m, center);
        // The meteorite body is complete at this point. Carve a small, enclosed
        // 1x1x2 chamber at its real centre (centerY is deliberately below the
        // impact surface) and only then install the pocket door.
        placePocketDoorChamber(m, center);
        m.level.method_8396(null, center, class_3417.field_14865, class_3419.field_15252, 10.0F, 0.55F);
        m.level.method_8396(null, center, class_3417.field_15152, class_3419.field_15245, 10.0F, 0.65F);
        // Large visual blast; the gameplay explosion never alters blocks.
        sendParticles(m.level, m.player, class_2398.field_11221, center.method_10263() + .5, center.method_10264() + .5, center.method_10260() + .5, 6, 2.5, 2.5, 2.5, 0);
        m.level.method_8537(null, center.method_10263() + .5, center.method_10264(), center.method_10260() + .5, m.radius * 1.35F, false, class_1927.class_4179.field_18685);
        IMPACTS.add(new ImpactAnimation(m.level, m.player, center.method_10263() + .5, center.method_10264() + .5, center.method_10260() + .5));
        m.player.method_43496(net.minecraft.class_2561.method_43470("Impact de météorite !"));
    }

    private static void placePocketDoorChamber(Meteorite m, class_2338 center) {
        // The exact registered block is PocketDoorMod.POCKET_DOOR (Content.java
        // does not declare a pocket-door block). The chamber is intentionally
        // one block wide so the meteorite shell remains around it on every side.
        class_2338 lower = new class_2338(center.method_10263(), center.method_10264(), center.method_10260());
        class_2338 upper = new class_2338(center.method_10263(), center.method_10264() + 1, center.method_10260());
        if (!m.level.method_22340(lower) || !m.level.method_22340(upper)) return;

        // Clear both cells after buildBody(), ensuring the cavity cannot be
        // overwritten by meteorite generation.
        m.level.method_8652(lower, class_2246.field_10124.method_9564(), 3);
        m.level.method_8652(upper, class_2246.field_10124.method_9564(), 3);

        class_2350 facing = m.player.method_5735().method_10153();
        class_2680 door = PocketDoorMod.POCKET_DOOR.method_9564();
        if (door.method_28498(class_2383.field_11177)) {
            door = door.method_11657(class_2383.field_11177, facing);
        }
        if (door.method_28498(class_2741.field_12533)) {
            m.level.method_8652(lower, door.method_11657(class_2741.field_12533, class_2756.field_12607), 3);
            m.level.method_8652(upper, door.method_11657(class_2741.field_12533, class_2756.field_12609), 3);
        } else {
            // PocketDoorBlock is a single-cell block in the available sources;
            // retain one air block above it for the requested two-block cavity.
            m.level.method_8652(lower, door, 3);
        }
    }

    private static void carveCrater(Meteorite m, class_2338 center) {
        int outer = m.radius + 3;
        for (int dx = -outer; dx <= outer; dx++) for (int dz = -outer; dz <= outer; dz++) for (int dy = -2; dy <= m.radius / 2 + 2; dy++) {
            double ellipsoid = (dx * dx + dz * dz) / (double) (outer * outer) + (dy * dy) / (double) ((m.radius + 2) * (m.radius + 2));
            class_2338 pos = center.method_10069(dx, dy, dz);
            if (ellipsoid <= 1.0 && m.level.method_22340(pos) && pos.method_10264() >= m.level.method_31607()) m.level.method_8652(pos, class_2246.field_10124.method_9564(), 3);
        }
        class_5819 r = m.level.field_9229;
        for (int i = 0; i < outer * outer * 2; i++) {
            int dx = r.method_43048(outer * 2 + 1) - outer, dz = r.method_43048(outer * 2 + 1) - outer;
            if (dx * dx + dz * dz <= outer * outer && Math.abs(dx * dx + dz * dz - m.radius * m.radius) < outer * 2) {
                class_2338 pos = new class_2338(m.x + dx, m.groundY, m.z + dz);
                if (m.level.method_22340(pos)) m.level.method_8652(pos, r.method_43056() ? class_2246.field_23869.method_9564() : (r.method_43056() ? class_2246.field_10092.method_9564() : class_2246.field_10515.method_9564()), 3);
            }
        }
    }

    private static void launchDebris(Meteorite m, class_2338 center) {
        // Blocks are placed in air immediately above the impact and converted through the
        // public 1.19.2 FallingBlockEntity.fall(...) factory. No private constructor or
        // reflection is required; the launch positions are deliberately in the air.
        class_5819 r = m.level.field_9229;
        class_2680[] debris = { class_2246.field_22423.method_9564(), class_2246.field_22091.method_9564(),
                class_2246.field_23869.method_9564(), class_2246.field_10092.method_9564(),
                class_2246.field_23077.method_9564() };
        int amount = 100 + r.method_43048(51);
        for (int i = 0; i < amount; i++) {
            double angle = r.method_43058() * Math.PI * 2.0;
            double horizontal = 1.5 + r.method_43058() * 4.0;
            double launchX = center.method_10263() + .5 + Math.cos(angle) * horizontal;
            double launchY = center.method_10264() + 2.0 + r.method_43058() * 2.5;
            double launchZ = center.method_10260() + .5 + Math.sin(angle) * horizontal;
            class_2338 launch = new class_2338((int) Math.floor(launchX), (int) Math.floor(launchY), (int) Math.floor(launchZ));
            m.level.method_8652(launch, debris[r.method_43048(debris.length)], 3);
            class_1540 shard = class_1540.method_40005(m.level, launch, m.level.method_8320(launch));
            shard.method_5814(launchX, launchY, launchZ);
            shard.method_5875(true);
            shard.method_18800(Math.cos(angle) * (1.8 + r.method_43058() * 1.7),
                    1.6 + r.method_43058() * 1.9, Math.sin(angle) * (1.8 + r.method_43058() * 1.7));
            shard.field_7193 = false;
        }
    }

    private static void buildBody(Meteorite m, class_2338 center) {
        class_5819 random = m.level.field_9229;
        int limit = class_3532.method_15384(m.radius * 1.25);
        for (int dx = -limit; dx <= limit; dx++) for (int dy = -limit; dy <= limit; dy++) for (int dz = -limit; dz <= limit; dz++) {
            double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (dist > m.radius * 1.25) continue;
            double noise = valueNoise(dx, dy, dz);
            double bumps = ((hash(dx * 13 + 7, dy * 17 + 3, dz * 23 + 11) & 31) / 31.0 - .5) * .16;
            if (dist > m.radius * (0.75 + 0.35 * noise + bumps)) continue;
            class_2338 pos = center.method_10069(dx, dy, dz); if (!m.level.method_22340(pos)) continue;
            double core = dist / Math.max(1, m.radius);
            class_2680 state;
            int roll = random.method_43048(100);
            if (core < .42) state = roll < 3 ? class_2246.field_22109.method_9564() : roll < 14 ? class_2246.field_23077.method_9564() : roll < 35 ? class_2246.field_23880.method_9564() : class_2246.field_10092.method_9564();
            else if (roll < 20) state = class_2246.field_22423.method_9564();
            else if (roll < 36) state = class_2246.field_10540.method_9564();
            else if (roll < 55) state = class_2246.field_23869.method_9564();
            else if (roll < 68) state = class_2246.field_23151.method_9564();
            else if (roll < 80) state = class_2246.field_22091.method_9564();
            else if (roll < 92) state = class_2246.field_10515.method_9564();
            else if (roll < 97) state = class_2246.field_23077.method_9564();
            else state = class_2246.field_10092.method_9564();
            m.level.method_8652(pos, state, 3);
        }
    }

    private static double valueNoise(int x, int y, int z) { return (hash(x / 2, y / 2, z / 2) & 1023) / 1023.0; }
    private static int hash(int x, int y, int z) { int h = x * 73428767 ^ y * 912931 ^ z * 42317861; h = (h ^ (h >>> 13)) * 1274126177; return h ^ (h >>> 16); }

    private static void impactParticles(ImpactAnimation e) {
        class_5819 r = e.level.field_9229;
        float t = Math.min(1.0F, e.age / 36.0F);
        double shell = 4.0 + t * 45.0;
        // Expanding ground shock ring, sampled as many individual points for a crisp circle.
        int ringPoints = 72 + e.age * 2;
        for (int i = 0; i < ringPoints; i++) {
            double a = Math.PI * 2.0 * i / ringPoints;
            double x = e.x + Math.cos(a) * shell, z = e.z + Math.sin(a) * shell;
            sendParticles(e.level, e.focus, i % 3 == 0 ? class_2398.field_11240 : class_2398.field_11237,
                    x, e.y - .35 + r.method_43058() * .35, z, 1, .16, .25, .16, .025);
        }
        // Several expanding hemispherical shells: only the upper half is emitted.
        for (int layer = 0; layer < 5; layer++) {
            double radius = 5.0 + t * (27.0 + layer * 6.0), yOffset = layer * 1.1;
            int points = 28 + layer * 6;
            for (int i = 0; i < points; i++) {
                double a = Math.PI * 2.0 * i / points;
                double elevation = (Math.PI * .5) * ((i % 7 + 1) / 7.0);
                double horizontal = Math.cos(elevation) * radius;
                double x = e.x + Math.cos(a) * horizontal;
                double y = e.y + yOffset + Math.sin(elevation) * radius;
                double z = e.z + Math.sin(a) * horizontal;
                sendParticles(e.level, e.focus, layer == 1 ? class_2398.field_11239 : class_2398.field_11240,
                        x, y, z, 1, .2, .2, .2, .02);
            }
        }
        sendParticles(e.level, e.focus, class_2398.field_11221, e.x, e.y, e.z, e.age < 5 ? 5 : 0, 2.5, 2.5, 2.5, 0);
    }

    public static void beginFromDoor(class_3222 player) { beginSequence(player); }
    private static void beginSequence(class_3222 player) { if (ACTIVE_DIALOGUES.add(player.method_5667())) PENDING.add(new Pending(player, 100)); }
    public static boolean isFinished(class_3222 player) { return PocketDoorSavedData.get(player.method_14220()).isFinished(player.method_5667()); }
    public static void sendStartDialogue(class_3222 player) { ServerPlayNetworking.send(player, START_DIALOGUE, PacketByteBufs.empty()); }
    public static void sendCartostellaireStart(class_3222 player, class_2338 pos) { class_2540 buf = PacketByteBufs.create(); buf.method_10807(pos); ServerPlayNetworking.send(player, CARTOSTELLAIRE_START, buf); }
    private ModMessages() {}
}
