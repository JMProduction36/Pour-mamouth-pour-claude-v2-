package fr.jmproduction.pocketdoor.network;

import fr.jmproduction.pocketdoor.PocketDoorMod;
import fr.jmproduction.pocketdoor.data.PocketDoorSavedData;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2398;
import net.minecraft.class_2902;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.ArrayList;
import java.util.List;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public final class ModMessages {
    public static final class_2960 OPEN_POCKET_DOOR = id("open_pocket_door");
    public static final class_2960 START_DIALOGUE = id("start_dialogue");
    public static final class_2960 DIALOGUE_FINISHED = id("dialogue_finished");

    private static final List<Pending> PENDING = new ArrayList<>();
    private static final List<Placement> PLACEMENTS = new ArrayList<>();
    private static final Set<UUID> ACTIVE = new HashSet<>();

    private record Pending(class_3222 player, int ticks, boolean blindnessApplied) {
    }

    private record Placement(class_3222 player, int ticks) {
    }

    private static class_2960 id(String path) {
        return new class_2960(PocketDoorMod.MOD_ID, path);
    }

    public static void registerC2SPackets() {
        ServerPlayNetworking.registerGlobalReceiver(
                OPEN_POCKET_DOOR,
                (server, player, handler, buffer, responseSender) -> server.execute(
                        () -> PLACEMENTS.add(new Placement(player, 60))
                )
        );

        ServerPlayNetworking.registerGlobalReceiver(
                DIALOGUE_FINISHED,
                (server, player, handler, buffer, responseSender) -> server.execute(
                        () -> {
                            PocketDoorSavedData.get(player.method_14220()).markFinished(player.method_5667());
                            player.method_6016(class_1294.field_38092);
                            player.method_6016(class_1294.field_5919);
                            ACTIVE.remove(player.method_5667());
                        }
                )
        );

        ServerTickEvents.END_SERVER_TICK.register(ModMessages::tick);
    }

    public static void beginFromDoor(class_3222 player) {
        beginSequence(player);
    }

    private static void beginSequence(class_3222 player) {
        if (!ACTIVE.add(player.method_5667())) {
            return;
        }

        // Audio is server-owned so a duplicate client packet cannot duplicate it.
        player.method_14220().method_8396(null, player.method_24515(), PocketDoorMod.AMBIANCE_SILGO,
                net.minecraft.class_3419.field_15256, 1.0F, 1.0F);
        player.method_6092(new class_1293(class_1294.field_38092, Integer.MAX_VALUE, 0, false, false));
        PENDING.add(new Pending(player, 100, false));
    }

    private static void tick(MinecraftServer server) {
        for (int index = PLACEMENTS.size() - 1; index >= 0; index--) {
            Placement placement = PLACEMENTS.get(index);
            if (!placement.player().method_5805() || placement.player().field_13987 == null) {
                PLACEMENTS.remove(index);
            } else if (placement.ticks() <= 1) {
                place(placement.player());
                PLACEMENTS.remove(index);
            } else {
                PLACEMENTS.set(index, new Placement(placement.player(), placement.ticks() - 1));
            }
        }

        for (int index = PENDING.size() - 1; index >= 0; index--) {
            Pending pending = PENDING.get(index);
            class_3222 player = pending.player();

            if (!player.method_5805() || player.field_13987 == null) {
                ACTIVE.remove(player.method_5667());
                PENDING.remove(index);
                continue;
            }

            int ticks = pending.ticks() - 1;
            boolean blindnessApplied = pending.blindnessApplied();
            if (!blindnessApplied && ticks <= 90) {
                player.method_6092(new class_1293(class_1294.field_5919, Integer.MAX_VALUE, 0, false, false));
                blindnessApplied = true;
            }

            if (ticks <= 0) {
                sendStartDialogue(player);
                PENDING.remove(index);
            } else {
                PENDING.set(index, new Pending(player, ticks, blindnessApplied));
            }
        }
    }

    private static void place(class_3222 player) {
        class_3218 level = player.method_14220();
        class_2350 facing = player.method_5735().method_10153();
        class_2338 position = player.method_24515().method_10079(player.method_5735(), 6);
        position = new class_2338(
                position.method_10263(),
                level.method_8624(class_2902.class_2903.field_13197, position.method_10263(), position.method_10260()),
                position.method_10260()
        );

        level.method_8652(
                position,
                PocketDoorMod.POCKET_DOOR.method_9564().method_11657(
                        class_2383.field_11177,
                        facing
                ),
                3
        );
        level.method_14199(
                class_2398.field_11240,
                position.method_10263() + 0.5,
                position.method_10264() + 1,
                position.method_10260() + 0.5,
                12,
                0.3,
                0.5,
                0.3,
                0.02
        );
    }

    public static boolean isFinished(class_3222 player) {
        return PocketDoorSavedData.get(player.method_14220()).isFinished(player.method_5667());
    }

    public static void sendStartDialogue(class_3222 player) {
        ServerPlayNetworking.send(player, START_DIALOGUE, PacketByteBufs.empty());
    }

    private ModMessages() {
    }
}