package fr.jmproduction.pocketdoor.network;

import fr.jmproduction.pocketdoor.PocketDoorMod;
import fr.jmproduction.pocketdoor.data.PocketDoorSavedData;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1294;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2398;
import net.minecraft.class_2902;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.ArrayList;
import java.util.List;

public final class ModMessages {
    public static final class_2960 OPEN_POCKET_DOOR = id("open_pocket_door");
    public static final class_2960 START_DIALOGUE = id("start_dialogue");
    public static final class_2960 DIALOGUE_FINISHED = id("dialogue_finished");
    private static final List<Pending> PENDING = new ArrayList<>();
    private static final List<BlindnessTask> BLINDNESS_TASKS = new ArrayList<>();
    private record Pending(class_3222 player, int ticks) {}
    private record BlindnessTask(class_3222 player, int ticks) {}
    private static class_2960 id(String path) { return new class_2960(PocketDoorMod.MOD_ID, path); }

    public static void registerC2SPackets() {
        ServerPlayNetworking.registerGlobalReceiver(OPEN_POCKET_DOOR, (server, player, handler, buffer, responseSender) -> server.execute(() -> PENDING.add(new Pending(player, 60))));
        ServerPlayNetworking.registerGlobalReceiver(DIALOGUE_FINISHED, (server, player, handler, buffer, responseSender) -> server.execute(() -> {
            PocketDoorSavedData.get(player.method_14220()).markFinished(player.method_5667());
            clearDialogueEffects(player);
        }));
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> server.execute(() -> {
            clearDialogueEffects(handler.field_14140);
            PENDING.removeIf(p -> p.player() == handler.field_14140);
            BLINDNESS_TASKS.removeIf(t -> t.player() == handler.field_14140);
        }));
        ServerTickEvents.END_SERVER_TICK.register(ModMessages::tick);
    }

    public static void scheduleDialogueBlindness(class_3222 player, int delayTicks) {
        BLINDNESS_TASKS.removeIf(task -> task.player() == player);
        BLINDNESS_TASKS.add(new BlindnessTask(player, delayTicks));
    }

    private static void tick(MinecraftServer server) {
        for (int i = BLINDNESS_TASKS.size() - 1; i >= 0; i--) {
            BlindnessTask task = BLINDNESS_TASKS.get(i);
            if (!task.player().method_5805() || task.player().field_13987 == null) { BLINDNESS_TASKS.remove(i); continue; }
            if (task.ticks() <= 1) {
                task.player().method_6092(new net.minecraft.class_1293(class_1294.field_5919, Integer.MAX_VALUE, 0, false, false));
                BLINDNESS_TASKS.remove(i);
            } else BLINDNESS_TASKS.set(i, new BlindnessTask(task.player(), task.ticks() - 1));
        }
        for (int i = PENDING.size() - 1; i >= 0; i--) {
            Pending pending = PENDING.get(i);
            if (pending.ticks() <= 1) { place(pending.player()); PENDING.remove(i); }
            else PENDING.set(i, new Pending(pending.player(), pending.ticks() - 1));
        }
    }

    private static void clearDialogueEffects(class_3222 player) {
        player.method_6016(class_1294.field_38092);
        player.method_6016(class_1294.field_5919);
        BLINDNESS_TASKS.removeIf(task -> task.player() == player);
    }

    private static void place(class_3222 player) {
        class_3218 level = player.method_14220(); class_2350 facing = player.method_5735().method_10153();
        class_2338 position = player.method_24515().method_10079(player.method_5735(), 6);
        position = new class_2338(position.method_10263(), level.method_8624(class_2902.class_2903.field_13197, position.method_10263(), position.method_10260()), position.method_10260());
        level.method_8652(position, PocketDoorMod.POCKET_DOOR.method_9564().method_11657(class_2383.field_11177, facing), 3);
        level.method_14199(class_2398.field_11240, position.method_10263() + .5, position.method_10264() + 1, position.method_10260() + .5, 12, .3, .5, .3, .02);
    }
    public static boolean isFinished(class_3222 player) { return PocketDoorSavedData.get(player.method_14220()).isFinished(player.method_5667()); }
    public static void sendStartDialogue(class_3222 player) { ServerPlayNetworking.send(player, START_DIALOGUE, PacketByteBufs.empty()); }
    private ModMessages() {}
}
