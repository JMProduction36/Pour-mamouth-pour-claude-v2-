package fr.jmproduction.pocketdoor.recipe; import fr.jmproduction.pocketdoor.Content;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.world.item.*; import java.util.*;
public final class ResonanceRecipes { public record Entry(class_1792 input, class_1799 output, int ticks){} private static final List<Entry> ALL=new ArrayList<>(); static{register(Content.RAW_TERTARIUM,Content.PURIFIED_TERTARIUM_CRYSTAL,200);register(class_1802.field_33400,class_1802.field_8620,160);register(class_1802.field_33402,class_1802.field_8695,180);register(class_1802.field_33401,class_1802.field_27022,140);} public static void register(class_1792 in,class_1792 out,int ticks){ALL.add(new Entry(in,new class_1799(out),ticks));} public static Entry find(class_1799 s){for(Entry e:ALL)if(e.input()==s.method_7909())return e;return null;} private ResonanceRecipes(){} }
