package fr.jmproduction.pocketdoor.world;

import fr.jmproduction.pocketdoor.PocketDoorMod;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2398;
import net.minecraft.class_2680;
import net.minecraft.class_2902;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import java.util.*;
import java.util.Map.Entry;

/** Server-side falling meteorite made of temporary real blocks. */
public final class MeteoriteManager {
    private static final int RADIUS=8, COOLDOWN=20*15;
    private static final Map<UUID,Integer> COOLDOWNS=new HashMap<>();
    private static final List<Meteorite> ACTIVE=new ArrayList<>();
    private static final Random RANDOM=new Random();
    private static final class Meteorite {
        final class_3218 level; final class_3222 owner; final int targetX,targetZ,groundY;
        int x,z,y; final Map<class_2338,class_2680> originals=new HashMap<>();
        Meteorite(class_3222 o,int tx,int tz,int gy,int sx,int sz,int sy){owner=o;level=o.method_14220();targetX=tx;targetZ=tz;groundY=gy;x=sx;z=sz;y=sy;}
    }
    private MeteoriteManager(){}
    public static void register(){ServerTickEvents.END_SERVER_TICK.register(server->{
        COOLDOWNS.replaceAll((id,v)->Math.max(0,v-1));
        for(int i=ACTIVE.size()-1;i>=0;i--){Meteorite m=ACTIVE.get(i); if(!m.level.method_22340(new class_2338(m.x,m.y,m.z))) continue;
            restore(m); int dx=Integer.compare(m.targetX,m.x), dz=Integer.compare(m.targetZ,m.z); m.x+=dx; m.z+=dz; m.y--;
            if(m.y-RADIUS<=m.groundY || !m.level.method_8320(new class_2338(m.x,m.y-RADIUS-1,m.z)).method_26215()){impact(m);ACTIVE.remove(i);} else place(m);
        }
    }); }
    public static void summon(class_3222 player){
        UUID id=player.method_5667(); if(COOLDOWNS.getOrDefault(id,0)>0) return;
        class_2350 d=player.method_5735(); int distance=90+RANDOM.nextInt(21);
        int tx=player.method_24515().method_10263()+d.method_10148()*distance, tz=player.method_24515().method_10260()+d.method_10165()*distance;
        int ground=player.method_14220().method_8624(class_2902.class_2903.field_13203,tx,tz)-1;
        int sx=tx-d.method_10148()*14, sz=tz-d.method_10165()*14, sy=ground+RADIUS+distance;
        Meteorite m=new Meteorite(player,tx,tz,ground,sx,sz,sy); COOLDOWNS.put(id,COOLDOWN); place(m); ACTIVE.add(m);
    }
    public static void disconnect(UUID id){for(int i=ACTIVE.size()-1;i>=0;i--)if(ACTIVE.get(i).owner.method_5667().equals(id)){restore(ACTIVE.remove(i));}COOLDOWNS.remove(id);}
    private static void place(Meteorite m){for(int dx=-RADIUS;dx<=RADIUS;dx++)for(int dy=-RADIUS;dy<=RADIUS;dy++)for(int dz=-RADIUS;dz<=RADIUS;dz++){int d=dx*dx+dy*dy+dz*dz;if(d>RADIUS*RADIUS)continue;class_2338 p=new class_2338(m.x+dx,m.y+dy,m.z+dz);if(!m.level.method_22340(p))continue;m.originals.putIfAbsent(p,m.level.method_8320(p));class_2680 s=d<=36?class_2246.field_22423.method_9564():(d<=100?class_2246.field_22091.method_9564():((Math.abs(dx)+Math.abs(dy)+Math.abs(dz))%11==0?class_2246.field_10205.method_9564():class_2246.field_22091.method_9564()));m.level.method_8652(p,s,3);if(RANDOM.nextInt(8)==0)m.level.method_14199(class_2398.field_11240,p.method_10263()+.5,p.method_10264()+.5,p.method_10260()+.5,1,0,0,0,0);}}
    private static void restore(Meteorite m){for(var e:m.originals.entrySet())if(m.level.method_22340(e.getKey()))m.level.method_8652(e.getKey(),e.getValue(),3);m.originals.clear();}
    private static void impact(Meteorite m){m.y=m.groundY+RADIUS;place(m);class_2338 p=new class_2338(m.x,m.groundY+1,m.z);m.level.method_8396(null,p,class_3417.field_15152,class_3419.field_15245,3f,.65f);m.level.method_14199(class_2398.field_11221,p.method_10263(),p.method_10264(),p.method_10260(),2,2,1,2,.1);m.level.method_14199(class_2398.field_11239,p.method_10263(),p.method_10264(),p.method_10260(),80,3,2,3,.2);class_2350 f=m.owner.method_5735().method_10153();m.level.method_8652(new class_2338(m.x,m.groundY+RADIUS*2+1,m.z),PocketDoorMod.POCKET_DOOR.method_9564().method_11657(class_2383.field_11177,f),3);}
}
