package fr.jmproduction.pocketdoor.worldgen;

import fr.jmproduction.pocketdoor.PocketDoorMod;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.class_2378;
import net.minecraft.class_2893;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6796;

public final class TertariumWorldGen {
    private static final class_5321<class_6796> TERTARIUM = class_5321.method_29179(
            class_2378.field_35758,
            new class_2960(PocketDoorMod.MOD_ID, "deepslate_tertarium_ore"));
    public static void register() {
        BiomeModifications.addFeature(BiomeSelectors.foundInOverworld(),
                class_2893.class_2895.field_13176, TERTARIUM);
    }
    private TertariumWorldGen() { }
}
